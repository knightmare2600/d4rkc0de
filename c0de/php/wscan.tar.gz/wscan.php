<? 

/*
			HTTP Server Header Scan [Xinstict]

			It sends http requests to multiple
			servers, gets responds from them, 
			gathers http server header, logs
			targered string of header.

*	It's not tcp banner scanner.
* U don't need curl extension for php.

Xinstict[at]gmail[dot]com
2007

*/

$scanfile = 'list.txt';			//list of domains/ips
$targets	= 'targets.txt';	//list of target types: Apache etc
$logfile	= 'log.txt';

include "httplib.php"; //needed

echo "[-] Scan started: ";
$stajebre = array_map('trim', file('targets.txt'));
foreach ($stajebre as $stringbre)
{echo "$stringbre ";
}echo "\n\n";

function XIscan($prvo,$targets,$logfile)
{
	$http = new Net_HTTP_Client();
	$http->Connect( "$prvo", 80 ) or $http->Disconnect();
	$status = $http->Get( "/" );
	
	$headers = $http->getHeaders();
	$srv_header = $headers["Server"];
	
	$headerweseek = array_map('trim', file($targets));
	//print_r($headerweseek);
	foreach ($headerweseek as $by_one_header_bre)
	{
	$headercheck = strpos($srv_header, $by_one_header_bre);
	if ($headercheck === false) { ; }
		else
	  {
		$ld = "$prvo	[$srv_header]\n";
		$lf = fopen($logfile, 'a');
		fwrite($lf, $ld);
		fclose($lf);
		echo " $prvo	- $srv_header	string: $by_one_header_bre\n";
		}
	};
	
	$http->Disconnect();
};

$staima = array_map('trim', file($scanfile));
foreach ($staima as $akcija)
{
@XIscan($akcija,$targets,$logfile);
};

echo "\n[-] Scan complete\n[-] Xinstict\n";	//Editing this line means that u are ugly motherfucker who is happy when modifies echo string like> echo "by \'yeeey iam fuckin script kiddie yeee\'"
die();

?>