<?

/*
			HTTP Server Header Scan [Xinstict]

			It sends http requests to multiple
			servers, gets responds from them, 
			gathers http server header, logs
			targered string of header.

*	It's not tcp banner scanner.
* U don't need curl extension for php.
* Usage:
	php headerscan.php <domains/ips> <Apache> <logfile>

2007 Xinstict[at]gmail[dot]com
*/

$verbose = '2';
/* 2 - Outputs all domains/ips. 					Logs targered. 
	 1 - Outputs only targered domains/ips. Logs targered.
	 0 - Outputs nothing to console. 				Logs targered. */

include "httplib.php";
//needed

$scanfile = 		$argv[1];
$headerweseek = $argv[2];
$logdata  = 		$argv[3];
if ($argv[1] == '') { echo "[-] Server Header Scan\n[-] Xinstict[at]gmail[dot]com\n\nUsage:\nphp $argv[0] <domains/ips> <target/type> <logfile>\nphp $argv[0] list.txt Apache log.txt\n\n";die();}
else {echo "[-] Scan started - $headerweseek\n\n";};
function XIScan($url, $headerweseek, $logdata, $verbose){
	$http = new Net_HTTP_Client();
	$http->Connect( "$url", 80 ) or $http->Disconnect();
	$status = $http->Get( "/" );	
	$hd = $http->getHeaders();$srvhd = $hd["Server"];
	$headercheck = strpos($srvhd, $headerweseek);
	if ($headercheck === false) 
		{if ($verbose == '2') { 
			echo "    $url	$srvhd\n"; 
			} else {/**/};
	  } else {
	  	$ld = "$url	[$srvhd]\n";
			$lf = fopen($logdata, 'a');fwrite($lf, $ld);fclose($lf);	
			if ($verbose == '2') {	echo "[!] $url	$srvhd\n"; } elseif ($verbose == '1') {	echo "[!] $url	$srvhd\n"; }
			else {/**/;}
			};
	$http->Disconnect();
	}
$staima = array_map('trim', file($scanfile));
foreach ($staima as $akcija){XIScan($akcija,$headerweseek,$logdata,$verbose);
};
echo "\n[-] Scan complete\n[-] Xinstict[at]gmail[dot]com\n";
die();
?>