<?php
$asqli = array ( );
$asqli [ ] = '--';
$asqli [ ] = '-- OR a=a/*';
?>

