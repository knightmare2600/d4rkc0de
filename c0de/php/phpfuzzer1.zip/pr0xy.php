<?php
header ( 'Content-Type: text/plain' );
$source = trim ( file_get_contents ( 'pr0xy.txt' ) );
$proxies = explode ( "\n", $source );
echo $proxies [ rand ( 0, count ( $proxies ) - 1 ) ];
?>

