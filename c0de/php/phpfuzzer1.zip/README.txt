Based on RoMeO[DarkMindZ.com] PHP.Fuzzer; see README_original.txt

@title PHP Fuzzer
@language PHP
@author c0ke

Information
===========
Scans a uri for XSS, RFI, LFI, SQL Injection and Path disclosures.
Some options include custom User_Agent/Referer, scan choice, proxy and phproxy.

Installation
============
1. upload all files to your server
2. go to the director you uploaded the files to
3. ????
4. profit

Global Settings
===============
Open global.php to set a default phproxy or referer.

Proxy Generation
================
gen_pr0xy.php - used for generating a proxy list in pr0xy.txt
pr0xy.txt - chmod 0666 for use with gen_pr0xy.php

Local Testing
=============
Rename test.php.txt to test.php to test locally.

