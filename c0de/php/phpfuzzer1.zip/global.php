<?php
define ( 'PF_PHPROXY', 'http://www.phproxy.org/index.php?q=' );
define ( 'PF_REFERER', 'http://homeland.fbi.gov' );

include_once ( 'agents.php' );
include_once ( 'lfi.php' );
include_once ( 'sqli.php' );

$target_uri = isset ( $_POST [ 'target_uri' ] ) ? $_POST [ 'target_uri' ] : '';
$phproxy_uri = isset ( $_POST [ 'phproxy_uri' ] ) ? $_POST [ 'phproxy_uri' ] : '';
$proxy_uri = isset ( $_POST [ 'proxy_uri' ] ) ? $_POST [ 'proxy_uri' ] : '';
$custom_agent = isset ( $_POST [ 'custom_agent' ] ) ? $_POST [ 'custom_agent' ] : '';
$custom_referer = isset ( $_POST [ 'custom_referer' ] ) ? $_POST [ 'custom_referer' ] : '';
?>

