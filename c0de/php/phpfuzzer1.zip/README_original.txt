root@darkmindz.com~ cat /home/pr0jects/FuZZ/intro

Title: Fuzzer
Language: PHP
Author: RoMeO[DarkMindZ.com]

Info: PHP.FuZZeR, Make the routine of LFI / RFI / SQL / XSS / Path Disclosures checking go faster, by using this fuzzer.._
      Example of usage: http://www.target.com/index.php?id= / ?page= / ?lol= etc..._
      - Enj0y!

#EOF
root@darkmindz.com~ exit

