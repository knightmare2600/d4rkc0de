var Attack =
{
	
	Init: function ( )
	{
		$ ( 'formAttack' ).disable ( );
		$ ( 'fuzzBtn' ).observe ( 'click', function ( event )
		{
			$ ( 'fuzz' ).update ( '<div align="center"><img src="ajax-loader.gif" border="0" alt="Working..."/></div>' );
			new Ajax.Updater ( 'fuzz', 'attack.php',
			{
				method: 'post',
				postBody: $ ( 'formAttack' ).serialize ( )
			} );
		} );
		$ ( 'formAttack' ).enable ( );
		$ ( 'randomProxy' ).observe ( 'click', function ( event )
		{
			new Ajax.Request ( 'pr0xy.php',
			{
				onSuccess: function ( transport )
				{
					$ ( 'proxy_uri' ).value = transport.responseText;
				}
			} );
		} );
	}
	
};

Event.observe ( window, 'load', Attack.Init );

