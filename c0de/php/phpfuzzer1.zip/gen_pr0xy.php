<?php
function proxyList ( $_0 )
{
	global $proxies;
	
	$source = file_get_contents ( $_0 );
	$source = str_replace ( array ( 'proxy', 'anonymous', 'server', 'high-' ), '', $source );
	$source = preg_replace ( '#\w{3}-\d{2}\, \d{2}:\d{2}#', '', $source );
	$source = preg_replace ( '#<span class="\d+">(\d+)</span>#', '$1', $source );
	$source = str_replace ( array ( '<td>', '<tr>', '</td>', '</tr>' ), ' ', $source );
	$source = str_replace ( ":\n", ':', $source );
	
	preg_match_all ( '#[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}:[0-9]{2,4}#', $source, $matched );
	
	foreach ( $matched [ 0 ] AS $value )
	{
		$ip = trim ( $value );
		
		if ( !empty ( $ip ) )
		{
			$proxies [ ] = $ip;
		}
		
	}
	
}

function proxyList2 ( )
{
	global $proxies;
	
	$source = file_get_contents ( 'http://www.nntime.com' );
	preg_match_all ( '#[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}:[0-9]{2,4}#', $source, $matched );
	
	foreach ( $matched [ 0 ] AS $value )
	{
		$ip = trim ( str_replace ( "\n", '', $value ) );
		
		if ( !empty ( $ip ) )
		{
			$proxies [ ] = $ip;
		}
		
	}
	
}

$proxies = array ( );
for ( $i = 1; $i < 30; ++ $i )
{
	$pnum = ( $i < 10 ) ? 'proxy-0' . $i . '.htm' : 'proxy-' . $i . '.htm';
	proxyList ( 'http://www.samair.ru/proxy/' );
}

proxyList2 ( );

file_put_contents ( 'pr0xy.txt', implode ( "\n", $proxies ) );
?>

