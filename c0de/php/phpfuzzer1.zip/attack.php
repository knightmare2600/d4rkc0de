<?php
include_once ( 'global.php' );

if ( empty ( $custom_agent ) )
{
	$custom_agent = $agents [ rand ( 0, count ( $agents ) - 1 ) ];
}

if ( empty ( $custom_referer ) )
{
	$custom_referer = PF_REFERER;
}

function URIExists ( $_0 )
{
	$curl = curl_init ( );
	curl_setopt ( $curl, CURLOPT_URL, $_0 );
	curl_setopt ( $curl, CURLOPT_BINARYTRANSFER, 1 );
	curl_setopt ( $curl, CURLOPT_HEADERFUNCTION, 'curlHeaderCallback' );
	curl_setopt ( $curl, CURLOPT_FAILONERROR, 1 );
	curl_setopt ( $curl, CURLOPT_TIMEOUT, 60 );
	curl_setopt ( $curl, CURLOPT_CONNECTIONTIMEOUT, 3 );
	@curl_exec ( $curl );
	$intReturnCode = curl_getinfo ( $curl, CURLINFO_HTTP_CODE );
	curl_close ( $curl );
	
	if ( $intReturnCode != 200 && $intReturnCode != 302 && $intReturnCode != 304 )
	{
		return 0;
	}
	
	return 1;
}

if ( empty ( $target_uri ) )
{
	echo 'Invalid Target';
}
elseif ( isset ( $_REQUEST [ 'use_phproxy_uri' ] ) && !URIExists ( $phproxy_uri ) )
{
	echo 'Invalid PHPRoxy';
}
elseif ( isset( $_SERVER [ 'HTTP_X_REQUESTED_WITH' ] ) && $_SERVER [ 'HTTP_X_REQUESTED_WITH' ]  == 'XMLHttpRequest' )
{
	echo '<table cellspacing="2" cellpadding="3" border="0" width="600">';
	echo '<tr><td style="background-color: #cc0000;"><strong>&#187; Attack Results</strong></td></tr>';
	$curl = curl_init ( );
	curl_setopt ( $curl, CURLOPT_USERAGENT, $custom_agent );
	curl_setopt ( $curl, CURLOPT_REFERER, $custom_referer );
	curl_setopt ( $curl, CURLOPT_TIMEOUT, 300 );
	curl_setopt ( $curl, CURLOPT_CONNECTIONTIMEOUT, 10 );
	
	if ( isset ( $_REQUEST [ 'use_proxy_uri' ] ) && !empty ( $proxy_uri ) )
	{
		curl_setopt ( $curl, CURLOPT_PROXY, $proxy_uri );
	}
	
	if ( isset ( $_REQUEST [ 'scan_xss' ] ) )
	{
		echo '<tr><td><strong>Scanning Cross Site Scripting</strong></td></tr>';
		$md5XSS = md5 ( 'xss' );
		$target = $target_uri . '<b>' . $md5XSS;
		
		if ( isset ( $_REQUEST [ 'use_phproxy_uri' ] ) && !empty ( $phproxy ) )
		{
			$target = $phproxy . base64_encode ( $target );
		}
		
		curl_setopt ( $curl, CURLOPT_URL, $target );
		curl_setopt ( $curl, CURLOPT_RETURNTRANSFER, 1 );
		echo '<tr><td> &nbsp; &nbsp; [ &lt;b&gt;' . $md5XSS . ' ] Attacking... ';
		$return = curl_exec ( $curl );
		
		if ( ereg ( '<b>' . $md5XSS, $return ) )
		{
			echo '<span style="color: #ff0000;">Found</span>.';
		}
		else
		{
			echo 'Done.';
		}
		
		echo '</td></tr>';
	}
	
	if ( isset ( $_REQUEST [ 'scan_lfi' ] ) )
	{
		echo '<tr><td><strong>Scanning Local File Inclusion - root</strong></td></tr>';
		
		foreach ( $alfi AS $value )
		{
			$target = $target_uri . $value;
			
			if ( isset ( $_REQUEST [ 'use_phproxy_uri' ] ) && !empty ( $phproxy ) )
			{
				$target = $phproxy . base64_encode ( $target );
			}
			
			curl_setopt ( $curl, CURLOPT_URL, $target );
			curl_setopt ( $curl, CURLOPT_RETURNTRANSFER, 1 );
			echo '<tr><td> &nbsp; &nbsp; [ ' . $value . ' ] Attacking... ';
			$return = curl_exec ( $curl );
			
			if ( eregi ( 'root', $return ) )
			{
				echo '<span style="color: #ff0000;">Found</span>.';
			}
			else
			{
				echo 'Done.';
			}
			
			echo '</td></tr>';
		}
		
	}
	
	if ( isset ( $_REQUEST [ 'scan_rfi' ] ) )
	{
		echo '<tr><td><strong>Scanning Remote File Inclusion - http://www.google.com/</strong></td></tr>';
		$target = $target_uri . 'http://www.google.com/';
		
		if ( isset ( $_REQUEST [ 'use_phproxy_uri' ] ) && !empty ( $phproxy ) )
		{
			$target = $phproxy . base64_encode ( $target );
		}
		
		curl_setopt ( $curl, CURLOPT_URL, $target );
		curl_setopt ( $curl, CURLOPT_RETURNTRANSFER, 1 );
		echo '<tr><td> &nbsp; &nbsp; [ &lt;title&gt;Google&lt;/title&gt; ] Attacking... ';
		$return = curl_exec ( $curl );
		
		if ( ereg ( '<title>Google</title>', $return ) )
		{
			echo '<span style="color: #ff0000;">Found</span>.';
		}
		else
		{
			echo 'Done.';
		}
		
		echo '</td></tr>';
	}
	
	if ( isset ( $_REQUEST [ 'scan_sqli' ] ) )
	{
		echo '<tr><td><strong>Scanning SQL Injection</strong></td></tr>';
		
		foreach ( $asqli AS $value )
		{
			$target = $target_uri . $value;
	
			if ( isset ( $_REQUEST [ 'use_phproxy_uri' ] ) && !empty ( $phproxy ) )
			{
				$target = $phproxy . base64_encode ( $target );
			}
			
			curl_setopt ( $curl, CURLOPT_URL, $target );
			curl_setopt ( $curl, CURLOPT_RETURNTRANSFER, 1 );
			echo '<tr><td> &nbsp; &nbsp; [ MySQL, on line, mysql_query ( ) ] Attacking... ';
			$return = curl_exec ( $curl );
			
			if ( eregi ( array ( 'MySQL', 'on line', 'mysq_query()' ), $return ) )
			{
				echo '<span style="color: #ff0000;">Found</span>.';
			}
			else
			{
				echo 'Done.';
			}
			
			echo '</td></tr>';
		}
		
	}
	
	if ( isset ( $_REQUEST [ 'scan_pd' ] ) )
	{
		echo '<tr><td><strong>Scanning Path Disclosure</strong></td></tr>';
		$target = str_replace ( '=', '', $target_uri ) . '[]=google.com';
		
		if ( isset ( $_REQUEST [ 'use_phproxy_uri' ] ) && !empty ( $phproxy ) )
		{
			$target = $phproxy . base64_encode ( $target );
		}
		
		curl_setopt ( $curl, CURLOPT_URL, $target );
		curl_setopt ( $curl, CURLOPT_RETURNTRANSFER, 1 );
		echo '<tr><td> &nbsp; &nbsp; [ Fatal, on line, Error ] Attacking... ';
		$return = curl_exec ( $curl );
		
		if ( eregi ( array ( 'Fatal', 'on line', 'Error' ), $return ) )
		{
			echo '<span style="color: #ff0000;">Found</span>.';
		}
		else
		{
			echo 'Done.';
		}
		
		echo '</td></tr>';
	}
	
	curl_close ( $curl );
	echo '</table>';
}
?>
