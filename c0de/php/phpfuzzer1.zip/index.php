<?php
include_once ( 'global.php' );
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head profile="http://www.w3.org/2000/08/w3c-synd/#">
	<title>PHP Fuzzer</title>
	<meta http-equiv="Content-Style-Type" content="text/css"/>
	<meta http-equiv="Content-Script-Type" content="text/javascript"/>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta http-equiv="Content-Language" content="en-US"/>
	<meta http-equiv="Expires" content="Mon, 26 Jul 1997 05:00:00 GMT"/>
	<meta http-equiv="Pragma" content="no-cache"/>
	<meta http-equiv="ImageToolBar" content="no"/>
	<meta name="MSSmartTagsPreventParsing" content="true"/>
	<link rel="Icon" type="image/x-icon" href="favicon.ico"/>
	<link rel="ShortCut Icon" type="image/x-icon" href="favicon.ico"/>
	<script type="text/javascript" language="JavaScript" src="prototype.js"></script>
	<script type="text/javascript" language="JavaScript" src="attack.js"></script>
	<link rel="StyleSheet" type="text/css" href="stylesheet.css"/>
</head>
<body>

<div id="wrapper">
<h1>PHP Fuzzer</h1>
<form name="formAttack" id="formAttack" action="#" method="get" onsubmit="return false;">
<table cellspacing="2" cellpadding="3" border="0" width="600">
<tr>
	<td width="135"><strong>Target URI:</strong> (<span onclick="$ ( 'options' ).toggle ( );" style="cursor: pointer;">options</span>)</td>
	<td><input type="text" name="target_uri" id="target_uri" value="http://" size="45"/> <input type="button" name="fuzzBtn" id="fuzzBtn" value=" Fuzz &#187; "/></td>
</tr>
</table>
<div id="options" style="display: none;">
<table cellspacing="2" cellpadding="3" border="0" width="600">
<tr>
	<td colspan="2" style="background-color: #cc0000; color: #fff;"><strong>&#187; Options</strong></td>
</tr>
<tr>
	<td width="135"><strong>Scan:</strong></td>
	<td><input type="checkbox" name="scan_xss" id="scan_xss" value="1" checked="checked"/> <label for="scan_xss">XSS</label> <input type="checkbox" name="scan_lfi" id="scan_lfi" value="1" checked="checked"/> <label for="scan_lfi">LFI</label> <input type="checkbox" name="scan_rfi" id="scan_rfi" value="1" checked="checked"/> <label for="scan_rfi">RFI</label> <input type="checkbox" name="scan_sqli" id="scan_sqli" value="1" checked="checked"/> <label for="scan_sqli">SQL Injection</label> <input type="checkbox" name="scan_pd" id="scan_pd" value="1" checked="checked"/> <label for="scan_pd">Path Disclosure</label></td>
</tr>
<tr>
	<td><strong>Proxy:</strong> <i>127.0.0.1:8181</i></td>
	<td><input type="checkbox" name="use_proxy_uri" id="use_proxy_uri" value="1" onclick="if ( this.checked ) { $ ( 'proxy_uri' ).enable ( ); } else { $ ( 'proxy_uri' ).disable ( ); }"/> <input type="text" name="proxy_uri" id="proxy_uri" value="" size="20" disabled="disabled"/> ( <span id="randomProxy" style="cursor: pointer;">random</span> )</td>
</tr>
<tr>
	<td><strong>PHProxy:</strong></td>
	<td><input type="checkbox" name="use_phproxy_uri" id="use_phproxy_uri" value="1" onclick="if ( this.checked ) { $ ( 'phproxy_uri' ).enable ( ); } else { $ ( 'phproxy_uri' ).disable ( ); }"/> <input type="text" name="phproxy_uri" id="phproxy_uri" value="<?=PF_PHPROXY;?>" size="45" disabled="disabled"/></td>
</tr>
<tr>
	<td><strong>User-Agent:</strong></td>
	<td><input type="text" name="custom_agent" id="custom_agent" value="<?=$agents [ rand ( 0, count ( $agents ) - 1 ) ];?>" size="40"/></td>
</tr>
<tr>
	<td><strong>Referer:</strong></td>
	<td><input type="text" name="custom_referer" id="custom_referer" value="<?=PF_REFERER;?>" size="25"/></td>
</tr>
</table>
</div>
<br/>
<div id="fuzz" style="width: 600px;">&nbsp;</div>
</div>

</body>
</html>

