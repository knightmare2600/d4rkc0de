<?php
/*******************************
Project name :online md5 crypter/decrypter
Beta version
Author Jjenn
Date: 18 Mar 2008
Contact : Jjenn.darkbox@gmail.com
http://darkbox.byethost13.com
File name : add.php
*******************************/

/*call config.php whitch contains database connexion functions*/
require('./config.php');
/*open the pass.txt file whitch contains pass list to add*/
if( $file = fopen('./upload/pass.txt', 'r') )
{  
	database_connect();
	/*while the file end is not reached*/
	while( !feof($file) )
	{
		/*store the first line in the pass variable*/
		$pass = fgets($file);
		
		/*check for $pass existance in the database*/
		$query  = sprintf("SELECT * FROM md5 WHERE plaintext='%s'", $pass);
		$result = mysql_query($query);
		$lines  = mysql_num_rows($result);
		/*no such entry in our database... we can add it !*/
		if( $lines == 0 or $lines == FALSE )
		{
			$md5_hash = md5($pass);
			$query  = sprintf("INSERT INTO md5 VALUES('', '%s', '%s', '%s')", $pass, $md5_hash, time() );
			if( !($result = mysql_query($query)) )
			{ echo"Can't add <b>".$pass."</b> to the current database !<br>"; }
			else
			{ echo "<b>".$pass."</b> successfully added !<br>"; }
			
		}
		/*an entry with the given plaintext was found in our database we don't add this one ! */
		else
		{
			echo $pass." exists, no need to add it again !<br>";
		}
	}
	database_close();
}
else
{  echo"File cant be opened !"; }
?>