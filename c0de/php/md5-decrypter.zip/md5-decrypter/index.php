<?php
/*******************************
Project name :online md5 crypter/decrypter
Beta version
Author Jjenn
Date: 18 Mar 2008
Contact : Jjenn.darkbox@gmail.com
http://darkbox.byethost13.com
File name : index.php
*******************************/

echo "<html>";
echo "<head>";
echo "<title>::The Darkbox:: md5 crypter decrypter</title>";
echo "<link rel='stylesheet' type='text/css' href='darkstyle.css'>";
echo "</head>";
echo "<body>";
	echo "<table align='center'>";
	echo "<tr><td><center><img src='./logo.png'></center></td></tr>";
	echo "</table><table align='center'>";
	echo "<tr><td></td></tr><br><br>";
	echo "</table><table align='center'>";
	echo "<tr><td><p>google adsens here !</p></td></tr></table>";
	echo "<table align='center'><form method='post'>";
	echo "<tr><td>";
	echo "<input type='text' name='pass'></td>";
	echo "<td><select name='option'><option value='crypt'>Crypt</option><option value='decrypt'>Decrypt</option></td>";
	echo "<td><input type='submit' name='send' value='Go  !'>";
	echo "</td></tr>";
	echo "</form></center><center></table><br><rb><table align='center'>";
	echo "<tr><td>";
	/*call check.php, containing the main programm*/
	include('./check.php');
	echo "</td></tr>";
	echo "</table>";
echo "</body>";
echo "</html>";
?>