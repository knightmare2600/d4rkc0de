<?php
/*******************************
Project name :online md5 crypter/decrypter
Beta version
Author Jjenn
Date: 18 Mar 2008
Contact : Jjenn.darkbox@gmail.com
http://darkbox.byethost13.com
File name : check.php
*******************************/


/*call confgi.php, containing main functions*/
require('./config.php');

/*If $pass variable does ot exist or is empty*/
if( isset($_POST['pass']) and (!empty($_POST['pass'])) )
{
	/*Verify if option content is correct*/
	$options = array('crypt', 'decrypt');
	if( isset($_POST['option']) and in_array($_POST['option'], $options) )
	{
		/*secure $pass against SQL and HTML injections*/
		database_connect();
		$pass = mysql_real_escape_string($_POST['pass']);
		$pass = htmlentities($pass);
		
		/*depending on option content, crypt or decrypt pass*/
		switch($_POST['option'])
		{
			case "crypt":
			/*Check for pass existance in the database.
			If it exists, we show md5 hash, if not, we crypt it, save it to the database, 
			and we show the result*/
			
			$query  = sprintf("SELECT * FROM md5 WHERE plaintext='%s'", $pass);
			$result = mysql_query($query);
			$lines  = mysql_num_rows($result);
			/*pass does not exist*/
			if($lines == FALSE or $lines == 0)
			{
				$hash = md5($pass);
				$query = sprintf("INSERT INTO md5 VALUE('', '%s', '%s', '%s')", $pass, $hash, time());
				$result = mysql_query($query);
				
				if(!$result)
				{ die("<center>Database erreor !</center>");}
				else
				{
					echo "<center><p>Plain text : <b>".$pass."</b><br>md5 hash : <b>".$hash."</b></></center>";
				}
			}
			/*pass exists*/
			else
			{
				$found = mysql_fetch_array($result);
				echo "<center><p>Plain text : <b>".$pass."</b><br>md5 hash : <b>".$found['md5hash']."</b></p><center>";
			}
			
			break;
			
			
			
			
			case "decrypt":
			/*check for pass existance in the database.
			If it exists, we show the plaintext, if not we show an error message*/
			
			$query  = sprintf("SELECT * FROM md5 WHERE md5hash='%s'", $pass);
			$result = mysql_query($query);
			$lines  = mysql_num_rows($result);
			/*pass does not exist*/
			if( $lines == FALSE or $lines ==0 )
			{ echo "<center><p> <b>".$pass."</b> does not exist in this database</p></center>"; }
			/*pass exists*/
			else
			{
				$found = mysql_fetch_array($result);
				echo "<center><p>md5 hash : <b>".$pass."</b> <br>Plain text : <b>".$found['plaintext']."</b></p>";
			}			
			break;
			database_close();
		}
	}
	/*Option does not exist or its content is invalid = hacking tentative*/
	else
	{
		die("<center>this site is not vulnerable to this kind of attack</center>");
	}
}
/*$pass is empty or does not exist, we show nothing*/
else
{
	echo "";
}
?>