<?php
/*******************************
Project name :online md5 crypter/decrypter
Beta version
Author Jjenn
Date: 18 Mar 2008
Contact : Jjenn.darkbox@gmail.com
http://darkbox.byethost13.com
file name : config.php
*******************************/

function database_connect()
{
	$dbhost = "localhost";
	$dblogin = "root";
	$dbpass = "";
	$database = "darkbox_hash";
	
	mysql_connect($dbhost, $dblogin, $dbpass) or die(mysql_error());
	mysql_select_db($database) or die(mysql_error());
}

function database_close()
{
	mysql_close();
}
?>