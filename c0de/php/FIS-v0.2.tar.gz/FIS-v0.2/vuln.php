<?php
error_reporting(E_ALL^E_NOTICE);

/*
 * Example file for FIS.
 *  
 */

 echo "<pre>\n";
 echo "I'm the vulnerable file !\n";

 $file = $_REQUEST['file'];
 include($file); // <-- vulnerable code, does not sanitise user parameter
 
 $file2 = $_REQUEST['file3'];
 include($file2); // <-- vulnerable code, does not sanitise user parameter

 echo "</pre>\n";

?>
