#! /usr/bin/php

<?php
/*
 * @project name:        FIS
 * @author:              zapotek <zapotek@segfault.gr>
 * @file name:           fis.php
 * @description:         File Inclusion Scanner
 *
 */
 
 error_reporting( 0 );
 
 define( 'VERSION', "0.1" );
 
 echo  "\nFIS [File Inclusion Scanner] v". VERSION . "\n" .
            "by Zapotek <zapotek@segfault.gr>\n" .
            "http://www.segfault.gr\n" .
            str_repeat( "-", 40 ) . "\n\n";
 
 // check if we have sufficient params
 if( $argc < 4 ) {
     echo "Usage: \n" .
          $argv[ 0 ] . " <local file> <remote file> <remote FIS ID file>\n";
     exit( );
 }
 
 // the first one is the script name
 array_shift( $argv ); 
 // the php source
 $local_file    = array_shift( $argv );
 // web location of the source
 $remote_file   = array_shift( $argv );
 // the remote location of the FIS ID file to include when auditing
 $fis_id    = array_shift( $argv );

 // check if the FIS ID file exists
 if( !url_exists( $fis_id ) ) {
     echo "FIS ID file doesn't exist...\n";
     exit( );
 }
 
 // check if the FIS ID file exists
 if( !url_exists( $remote_file ) ) {
     echo "Remote file doesn't exist...\n";
     exit( );
 }
 
 // check if the souce file exists 
 if( !file_exists( $local_file ) ) {
     echo "Local file doesn't exist...\n";
     exit( );
 }

 // try to read the souce file  
 if( !( $code   = file_get_contents( $local_file ) ) ) {
     echo "Could not read local file...\n";
     exit( );
 }
 
 // start the timer
 $start = getmicrotime( );

 // pass some info to the user
 echo "User settings:\n" . str_repeat( "-", 15 ) . "\n" .
      "Local file:     $local_file\n".
      "Remote file:    $remote_file\n".
      "FIS ID file:    $fis_id\n\n";

 // return the operation status
 echo "Status\n" . str_repeat( "-", 15 ) . "\n";
 echo "[*] Identifing variables... ";
 
 // extract variables from php source
 $vars  = get_vars( $code );
 
 // get the number of extracted variables
 if( $vars ) $var_num   = count( $vars );
 
 echo "Done!\n";

 echo "[*] Auditing remote script... ";
 
 // get vulnerable variables
 $results = audit( $remote_file, $vars );
 
 // get number of vulnerable variables
 if( $results ) $vuln_var_num = count( $results );
 echo "Done!\n";
     
  // pass results to the user
 echo "\nResults\n" . str_repeat( "-", 15 ) . "\n";
 echo "Number of variables:    " . (int)$var_num . "\n";
 echo "Number of vulnerable variables: " . (int)$vuln_var_num .
      " [" . round( 100 - ( ( $var_num - $vuln_var_num ) / $var_num ) * 100, 3 ) .
      "%]\n";
 
 if( $results ) {
     echo  "\nVulnerable GET variables\n";
     echo  str_repeat( "-", 30 ) . "\n";
     foreach( $results as $variable ) echo $variable . "\n";
 }
 
 echo "\n\n(See 'fis.log' for more details.)\n";
 
 // stop the timer
 $end = getmicrotime( );
 echo "\nFinished in " . ( $end - $start ) . " seconds\n" .
      str_repeat( "-", 40 ) . "\n";

 // timer function
 function getmicrotime( ) {
    list( $usec, $sec ) = explode( " ", microtime( ) );
    return( (float) $usec + (float) $sec );
 }

 if( !function_exists( 'file_put_contents' ) ) {
     /** 
      * @param filename  filename to get contents from
      * @param string_variable  where to put the contents
      * 
      * @return bool TRUE on success, FALSE on failure
      */
     function file_put_contents( $n, $d ) {
         $f = @ fopen( $n, "w" );
         if( !$f ) {
             return false;
         } else {
             fwrite( $f, $d );
             fclose( $f );
             return true;
         }
     }
 }


 /* --------------  vital functions    ---------------- */

 // the URL equivalent of file_exists()
 function url_exists( $url ) {
     $handle = @fopen( $url, "r" );
     if( $handle === false ){
          fclose( $handle );
          return false;
     } else {
         fclose( $handle );
         return true;
     }
     
 }
 
 // function for PHP/HTTP variable identification
 function get_vars( $code ) {
     // match variables using regex
     $regex['php_vars'] ='/\$[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*/';
     preg_match_all( $regex['php_vars'], $code, $php_matches );

     // POST/COOKIE support not yet implemented
     $regex['http_vars'] = '/\$_(GET|REQUEST)\[[\'"](.*)[\'"]]/';
     preg_match_all( $regex['http_vars'], $code, $http_matches);
     
     // merge the 2 arrays
     $matches = array_merge( $php_matches, $http_matches );
     
     // filter false positives
     foreach( $matches as $match ) {
         foreach( $match as $match_deep ) {
            $match_deep = str_replace( '$', "", $match_deep );
             if( ( !strstr( $match_deep, 'GET' ) ) && 
                 ( !strstr( $match_deep, 'REQUEST' ) ) && 
                 ( !strstr( $match_deep, 'COOKIE' ) ) &&  
                 ( !strstr( $match_deep, 'POST' ) ) )
                 $matched[] = $match_deep;
         }
     }
     
     // get rid of duplicates
     $vars = @array_unique( $matched );
     
     // for debugging
//     print_r($vars);
       
     return( $vars ) ? $vars : FALSE;
 }
 
 // the function that performs the audit
 function audit( $remote_file, $vars ) {
     global $fis_id;

     // keep log
     $log  = "\n" . date( 'l dS \of F Y h:i:s A') . " :: " .
             $remote_file . "\n";
     
     $log .= "URL parameter" .
             str_repeat( "\t", strlen( $remote_file ) / 6 ) .
             "\tStatus\n";
             
     $log .= str_repeat( "-", strlen( $remote_file ) * 2 ) . "\n";
     
     // loop through the vuln variable array trying to include the FIS ID file
    foreach( $vars as $var ) {
        $param = "?" . urlencode( $var ) . "=" . urlencode( $fis_id ) . "?";
        if( !$html = file_get_contents( $remote_file . $param ) ){
            return;
        }
        
        $log .= $param;
        
        if( strstr( $html, "d3612e6ae8c17e46fa8592c8bdb8f2f3" ) ) {
            $vulns[] = $var;
            $log .= "\tVulnerable";
        } else {
            $log .= "\tSafe";
        }            
        $log .= "\n";
    }
    
    // get current log contents
    $log2 = @file_get_contents( "fis.log" );

    if( !$log2 ) {
        $log = "Log file generated by FIS v" . VERSION . "\n" .
               str_repeat( "-", 35 ) . "\n" . $log;
    }

    // put oldest entries on top 
    file_put_contents( "fis.log", $log2 . $log );
      
    return( $vulns ) ? $vulns : FALSE;
 }
 

?>
