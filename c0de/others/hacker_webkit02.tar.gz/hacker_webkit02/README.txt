HACKER WEBKIT
=============
darkraver@open-labs.org


Concept
-------

Hacker-Webkit is a pack of scripts for doing pentest in a wide range webservers. Each module includes 3
components: Command execution, Directory + File navigation and File uploading. Current modules 
are: ASP, CFM, EXE, JSP, PHP, PL, SERVLET and SH.




Basic Components of each module:
--------------------------------

CMD - Command execution

LIST - Directory & File navigation

UP - File uploading



Current Modules:
----------------

ASP -> 0.3	(Microsoft VBS/ASP)
CFM -> 0.1	(Coldfusion)
EXE -> 0.1	(Compiled binary)
JSP -> 0.4	(Java Server Pages)
NET -> 0.1	(Microsoft ASP .NET)
PHP -> 0.2	(PHP)
PL -> 0.2 	(Perl)
SERVLET -> 0.2 	(Java Servlets)
SH -> 0.2	(Shell Script)



Maybe Future:
-------------

TCL 		(Vignette)
PY		(Python)
[Contributors needed]



TODO:
-----

asp_kit -> reprogramar up.asp
exe_kit -> list





"Keep it simple!"