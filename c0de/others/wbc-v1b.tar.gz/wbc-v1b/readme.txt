Web Backdoor Compilation (wbc)
DK (http://michaeldaw.org) 

Changelog
Date Change 
14 Apr 07 Version 1b (pre 1.2 release):
perlcmd.cgi,
cfexec.cfm,
cmdasp.aspx 
Dec/06 Version 1 release. 

I have collected some WEB backdoors in the past to exploit
vulnerable file upload facilities and others. I think a
library like this may be useful in a variety of situations. 

Understanding how these backdoors work can help security administrators implement firewalling and security policies to mitigate obvious attacks. 

The package includes: 

Filename Contributer MD5 
cmd-asp-5.1.asp Brett Moore 8baa99666bf3734cbdfdd10088e0cd9f 
cmdasp.asp Maceo 57b51418a799d2d016be546f399c2e9b 
cmdasp.aspx Dominic Chell 5e83b6ed422399de04408b80f3e5470e 
cmdjsp.jsp Unknown b815611cc39f17f05a73444d699341d4 
jsp-reverse.jsp Tan Chew Keong 8b0e6779f25a17f0ffb3df14122ba594 
php-backdoor.php z0mbie 2b5cb105c4ea9b5ebc64705b4bd86bf7 
simple-backdoor.php David Kierznowski f091d1b9274c881f8e41b2f96e6b9936 
perlcmd.cgi David Kierznowski 97ae7222d7f13e908c6d7f563cb1e72b 
cfexec.cfm Kurt Grutzmacher bd04f47283c53ca0ce6436a79ccd600f 

Note: readme.txt is also included in this package but not listed here. 

If you have contributions please let me know so that I can add them into a later
release. 


