
#ifdef I_AM_HOOK_DLL
#define API_HOOK_EXPORT extern "C" __declspec(dllexport)
#else
#define API_HOOK_EXPORT extern "C" __declspec(dllimport)
#endif

API_HOOK_EXPORT int WINAPI API_Hook_AllApps_Start(DWORD);
API_HOOK_EXPORT int WINAPI API_Hook_AllApps_Stop(void);
