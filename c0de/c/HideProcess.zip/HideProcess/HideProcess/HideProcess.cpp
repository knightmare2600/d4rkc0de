
/////////////////////////////////////////////////////////////////////
// HideProcess.cpp
/////////////////////////////////////////////////////////////////////

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifndef STRICT
#define STRICT
#endif

#include <windows.h>
#include <windowsx.h>
#include <tchar.h>
#include <stdlib.h>

#include "resource.h"

#include "HP.h"
#pragma comment(lib, "HP.lib")


#define ESM_POKECODEANDLOOKUP    (WM_USER + 101)


BOOL CALLBACK Dlg_Proc(HWND, UINT, WPARAM wParam, LPARAM);
void CallAPIHook(HWND, PTSTR, DWORD);
void CallOKButton(void);


int APIENTRY _tWinMain(HINSTANCE hInstance,
                       HINSTANCE hPrevInstance,
                       LPTSTR    lpCmdLine,
                       int       nCmdShow)
{
	// ��d�N���h�~�AFindWindow�������g�p
	HWND hWnd = FindWindow( _T("#32770"), _T("HideProcess"));
	if(IsWindow(hWnd))
		SendMessage(hWnd, ESM_POKECODEANDLOOKUP, 0, 0);
	else
		DialogBox(hInstance, MAKEINTRESOURCE(IDD_WINDOW), NULL, Dlg_Proc);
	API_Hook_AllApps_Stop();
	return 0;
}

// �t�b�N�̐���{�^��
void CallOKButton(HWND hWnd)
{
	static BOOL flag = TRUE;

	if(flag){
		TCHAR szPID[256];
		ZeroMemory(szPID, sizeof(szPID));
		Edit_GetText(GetDlgItem(hWnd, IDC_PID), szPID, sizeof(szPID));
		DWORD dwPID;
		if(szPID[0] == _T('\0'))
			dwPID = GetCurrentProcessId();
		else
			dwPID = atol(szPID);
		API_Hook_AllApps_Start(dwPID);
		Edit_SetText(GetDlgItem(hWnd, IDOK), _T("UN HIDE"));
	}else{
		API_Hook_AllApps_Stop();
		Edit_SetText(GetDlgItem(hWnd, IDOK), _T("HIDE"));
	}
	flag = flag ? false : true;
}

// �R�[���o�b�N
BOOL CALLBACK Dlg_Proc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case ESM_POKECODEANDLOOKUP:
		SetForegroundWindow(hWnd);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDOK:
			CallOKButton(hWnd);
			break;
		case IDCANCEL:
			EndDialog(hWnd, NULL);
			break;
		}
	}
	return FALSE;
}


////////////////////////////////////////////////////////////// EOF //
