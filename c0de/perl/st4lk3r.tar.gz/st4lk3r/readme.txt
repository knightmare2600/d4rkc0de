to use st4lk3r WVS you need to upload the program along with the following data

1 - path
2 - url
3 - system simule
4 - type log
5 - name log 

1 - path

-c               scanner the site in search of fails CGI
                 use: -c www.site.com...

-r               scanner the site in search of fails RFI
                 use: -r www.site.com...

-j               scanner the site in search of fails JOOMLA
                 use: -j www.site.com...

-l               scanner the site in search of fails LFI
                 use: -l www.site.com...

-s               scanner the site in search of fails SQL
                 use: -s www.site.com...

2 - url

use the url of the site you want scanner
use : -* www.site.com...

Note: The URL must be valid


3 - system simule

-bsd             simulates the operating system: NetBSD the scan
                 use: -* www.site.com -bsd...

-win             simulates the operating system: WindowsNT the scan
                 use: -* www.site.com -win...

-lnx             simulates the operating system: Linux the scan
                 use: -* www.site.com -lnx...


4 - type log

-t              saved in the log format: .txt
                use: -* www.site.com -*** -t ...

-h              saved in the log format: .html
                use: -* www.site.com -*** -h ...

-n              saved in the log format: NULL
                use: -* www.site.com -*** -n ...

Note: NULL = file without extension and the logs are 
saved in the same folder where the program


5 - name log 

select the name of the log
use: -* www.site.com -*** -* log_st4lk3r

Please note: you must log have a name


	
+Extra functions

proxy         What proxy: example 200.1.2.0:8080 If you do not
              want proxy to put: 0 or enter

Note: this function are in the middle of the program

-update       this function update the files of vulnerabilities and logs
              use: -update

-log          This function will delete the logs of your operating system
              use: -log

Note: You must select the operating system which must be cleared from the logs

-info         shows the credits and thanks the author of the program
              use: -info

Some examples of use of the program: 

perl st4lk3r.pl -s www.site.com -bsd -t log_site
perl st4lk3r.pl -j www.site.com -lnx -h log_site
perl st4lk3r.pl -r www.site.com -win -n log_site
perl st4lk3r.pl -update
perl st4lk3r.pl -info
	
+ endless possibilities