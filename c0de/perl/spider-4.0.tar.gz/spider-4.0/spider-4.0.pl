#!/usr/bin/perl

###
### Original authors: Cornell University IT Security Center
###
### Additional authors: Pred S. Bundalo, Northwestern University EECS Department
###	Wed May 16 09:50:31 CDT 2007 -- Added "-y" flag, "followsymlinks" config
###		file option, and supporting code.
###

# TO-DO:
# send session start/end to log server

use Getopt::Std;
use IO::Socket;
use POSIX qw(tmpnam);
use File::Basename;
use File::Temp qw/ :mktemp tempdir /;
use MD5;
use Crypt::CBC;
use Config::IniFiles;
use Fcntl;
use File::LibMagic ':easy';
use File::Path;
use LWP;

use Archive::Zip;


$STRINGS = "/usr/bin/strings";
$DEBUG = 0;
$OUT_DIR = "out/";
$ACROREAD = "/usr/local/bin/acroread -toPostScript ";
$FILE = "/usr/bin/file";
$WV = "/usr/bin/wvText";
$MUNPACK = "/usr/bin/munpack";
$UNZIP = "/usr/bin/unzip";
$UNRAR = "/usr/bin/unrar";
$LHA = "/usr/bin/lha";
$ZOO = "/usr/bin/unzoo";
$ARJ = "/usr/bin/arj";
$READPST = "/usr/bin/readpst";
$PORT = 3000;
$REGEXES = "REGEXES";
$MAX_LEN = $OLD_MAX_LEN = 1024;
$MAX_CHARS = 128;
$DISK = 0;
$LOG_HOST="127.0.0.1";
$TMP_OUT = "/tmp/spider"; # must make this directory first
$filecount = 0;
$skipped = 0;
$START_DIR = "out";
$quick = 1;
$quiet = 1;
$stupid = 0;
$encrypted_zips = 0;
$FOLLOWSYMLINKS = 0;	# Pred S. Bundalo, Wed May 16 09:25:36 CDT 2007
$BREAKAWAY = 0;
$SPIDER_CONF_PATH = "/var/tmp/spider_conf_path";

$ENCRYPT = 0;
$CIPHER = "Blowfish";

$CONFIG = "/tmp/spider.conf";

# file type logging
%files_by_type = ();

# our options:

&getopts('ybdsvuTSD:c:');

if ($opt_y) { $FOLLOWSYMLINKS = 1; }  # Pred S. Bundalo, Wed May 16 09:25:36 CDT 2007

if ($opt_b) { $BREAKAWAY = 1; } # for running under the spider GUI

if ($opt_d) { $DEBUG = 1; }

if ($opt_s) { $stupid = 1; }

if ($opt_v) { $quick = 0; $quiet = 0; }

if ($opt_u) {
	$unscrew_filenames = 1;
	$DISK = 1;
}

if ($opt_T) {
	print "Testing regexes\n";
	&test_patterns;
	exit(0);
}

if ($opt_D) {
	$DISK = 1;
	$START_DIR = $opt_D;
}


if ($opt_S) {
    &show_regexes;
    exit(0);
}


if ($opt_c) {
	$CONFIG = $opt_c;
}


unless ($opt_c) {
	open IFILE, "< $SPIDER_CONF_PATH" or die "can't open $SPIDER_CONF_PATH:$!\n";
	$_ = <IFILE>;
	s/\n//;
	$CONFIG = $_;
	close IFILE;
}

# read our config file
&read_config;

# create our temp directory
if ( ! -e $TMP_OUT ) { mkdir ($TMP_OUT, 0700); }

&load_regexes;

# see what tools we have
&set_tool_paths;

if ($ENCRYPT) {
       $cipher = Crypt::CBC -> new( { 'key' => $KEY, 
                                      'cipher' => $CIPHER
                                    } );
}

# for the convenience of the spider GUI
#
if ($BREAKAWAY) {
	$pid = fork();
	exit if $pid;
	die "Can't fork:$!\n" unless defined($pid);
	$sess = POSIX::setsid() or die "Can't start new session:$!\n";
	print "SPIDER_CLIENT_PID:$sess\n";
}

$SIG{TERM} = \&sig_handler;

if ($DISK) {
	$proc_path = $START_DIR . "/";
} else {
	$proc_path = $OUT_DIR . "/";
}
	&process_files($proc_path);

# generate a summary and send it over the socket

if ($SUMMARY) {
	&send_summary;
}

exit (0);


sub process_files {
    my $path = shift;

    return unless ($path);
    unless ($quiet) { print "Processing downloaded files in $path\n"; }

    opendir(DIR, $path) or die "unable to open $path:$!\n";

    local @files = grep { !/^\.{1,2}$/ } readdir(DIR);

    closedir (DIR);
    
    @files = map { $path . '/' . $_ } @files;

    for (@files) {
	if (-d $_) {
	    if (! -l $_ || (-l $_ && $FOLLOWSYMLINKS)) {  # Pred S. Bundalo, Wed May 16 09:25:36 CDT 2007
	    # recurse 
	    &process_files($_);
	    }
	} else {
	    # regex match the file
	    if ($unscrew_filenames) {
		&unscrew($_);
	    } else {
	    	&check_file($_);
	    }
	}
    }
    return;
} # end sub


sub check_file {
    $filecount++;
    local $file = shift;
    local $ofile = $file;
    local $nuke_dir = $ARK_DIR;

    # we'll bang a file command off it and see what turns out;
    # that way, we'll be prepared to handle a variety of file types
    # along the way, though it will slow us down considerably
	$resp = MagicFile($file);

	foreach $pat (@skip_types) {
		if ($resp =~ m/$pat/) {
			$skipped++;
			return;
		}
	}

	# archive support
	#

	if ($resp =~ m/archive/) {
		if ($UNPACK_ARCHIVES) {
			if ($resp =~ /Zip archive/) {
				$ARK_DIR = tempdir( DIR => "/tmp", 
					CLEANUP => 1 );
				&unzip_file($file, $ARK_DIR);
				if ($encrypted_zips) {
					# we'll log this and move on
					$files_by_type{'Encrypted ZIP'} += 
					rmtree($ARK_DIR);
					$skipped++;
					return;
				}
			} else {
				# external programs
				&create_archive_command;
				unless ($quiet) {
					print "Processing archive with command ($CMD)\n";
				}
				system($CMD);
			}
			&process_files($ARK_DIR);
			rmtree($ARK_DIR);
		} else {
			$skipped++;
		}
		return;
	}
	
	if ($resp =~ m/Outlook\sbinary/) {
		# use readpst to a temp directory
		$ARK_DIR = tempdir( DIR => "/tmp", CLEANUP => 1 );
		$CMD = $READPST . " -o " . $ARK_DIR . " " . $file;
		system($CMD);
		&process_files($ARK_DIR);
		rmtree($ARK_DIR);
		return;
	} elsif ($resp =~ m/mail\sfolder/) {
		$ARK_DIR = tempdir( DIR => "/tmp", CLEANUP => 1);
		$CMD = $MUNPACK . " -C " . $ARK_DIR . " > /dev/null 2>&1";
		open PIPE, "| $CMD";
		open IFILE, "< $file";
		binmode IFILE;
		while (<IFILE>) {
			print PIPE;
		}
		close IFILE;
		close PIPE;
		&process_files($ARK_DIR);
		rmtree($ARK_DIR);
		return;
	}

	# other mailboxes

	if ($resp =~ m/PDF/) {
		# use pdftotext to create a simple text file in a temp directory
		# we'll unlink it when done
		$TMP_FILE = $TMP_OUT . "/out.html." . $$;
		$TMP_IN = $TMP_FILE . ".orig";
		sysopen(FH, $file, O_RDONLY);
		open OFILE, "> $TMP_IN";
		binmode OFILE;
		while (sysread(FH, $buf, 32768)) {
			print OFILE $buf;
		}
		close FH;
		close OFILE;
		$PDF_CMD = "/usr/bin/pdftotext " . $TMP_IN . " " . $TMP_FILE;
		system($PDF_CMD);
		$ofile = $TMP_FILE;
		unlink($TMP_IN);
      	} elsif ($resp =~ m/HTML/ || 
		$resp =~ m/ASCII/ || 	
		$resp =~ m/English/ ||
		$resp =~ m/text/) {
		$ofile = $file;
	} else {
		# do our best for now
    	}

	# here we don't catch the huge volume of executable types,
	# images, and assorted other stuff we deliberately skip
	#

    	$files_by_type{$resp}++;

    	unless (sysopen(IFILE, $ofile, O_RDONLY)) {
    		close IFILE; print "skipping $ofile:$!\n"; return; 
    	}
	binmode IFILE;
    	# we're not going to send the data over to the server for matching;
    	# we'll do it in-line
	unless ($quiet) { print "Processing : $ofile\n"; }
	$tot_read = 0;
    	while (($r = sysread(IFILE, $msg, $OLD_MAX))) {
		$tot_read += $r;
		if ($MAX_DEPTH  > 0 && $tot_read >= $MAX_DEPTH) {
			close IFILE;
			unlink($TMP_FILE);
			return;
		}
		foreach $pat (@regexes) {
			if ($msg =~ /$pat/) {
				&send_match($msg);
				# quick means, take the first match
				if ($quick) { 
					close IFILE;
					unlink($TMP_FILE);
					return;
				}
			}
		}
	}
	close IFILE;
	unlink($TMP_FILE);
    	return;
}

sub show_regexes {
    print "Loading regular expressions.\n";
    $count = 0;
    
    open IFILE, "< $REGEXES" or die "cannot open $REGEXES:$!\n";
    
    while (<IFILE>) {
	next if (/^\n/ || /^\#/);
	chomp;
	$regex = $_;
	$count++;
	print "Regex: $regex\n";
	print "\n";
    }
    
    print "$count regular expressions loaded.\n";


    return;
}


sub test_patterns {
	open IFILE, "< $REGEXES" or die "cannot open $REGEXES:$!\n";

	while (<IFILE>) {
    		next if (/^\n/ || /^\#/);
    		chomp;
    		$regex = $_;
		if (&is_valid_pattern($regex) == 0) {
			print "Invalid pattern: \n$regex\n";
		}
	}

	return;

}

sub is_valid_pattern {
	my $pat = shift;
	print "Testing: $pat\n";
	return eval { "" =~ /$pat/; 1 } || 0;
}

sub unscrew {
	local $file = shift;

	# we'll regex match the file for shell meta characters;
	# anything not straightaway UNIX gets renamed

	if ($file =~ /[\s\?\!\|\\\$\%\^\&\*\-\+\;\:\'\"\<\>]/) {
		# generate a temp file name as a target
		$new_name = dirname($file) . "/" . mktemp("renamedXXXXXX");
		print "Renaming:\n";
		print "$file\n";
		print "to\n";
		print "$new_name\n";
		rename($file, $new_name);
	} else {
		print "Skipping $file\n";
	}

	return;
}

sub load_regexes {
	# load up the regexes and get ready to start matching
	$count = 0;
	$matches = 0;

	open IFILE, "< $REGEXES" or die "cannot open $REGEXES:$!\n";


	while (<IFILE>) {
    		next if (/^\n/ || /^\#/);
    		chomp;
		$regex = $_;
    		push(@regexes, qr/$regex/);
    		$count++;
	}
	
	return;

}

sub send_match {
	local $frag = shift;
	# open a socket to the log host
	# hash and encrypt if necessary,
	# then send the packet


	# in case we received a chunk of binary, we ought to clean it up
	if ($stupid) { $c = 1; }
	for ($i = 0; $i <= $OLD_MAX; $i++) {
		$bar = substr($frag, $i, 1);
		if ((ord($bar) <= 32 || ord($bar) >= 127)  &&
			(ord($bar) != 10)) { $bar = $UNPRINT; }
		$newmsg .= $bar;
		if ($stupid) {
			$c++;
			if ($c = $MAX_CHARS) {
				$newmsg .= "\n";
				$c = 1;
			}
		}
	}

	$frag = $newmsg;

	$newmsg = "";

	if ($LOG_HTTP) {
		# we'll post it to the URL given, then return

		return;
	}

	$ip_addr = inet_aton($LOG_HOST);
    	$portaddr = sockaddr_in($PORT, $ip_addr);
    	$start = 0;

    	$csock = IO::Socket::INET -> new(Proto => 'udp')
                or die "socket: $@\n";
	
    
	# our report will consist of:
	# SPIDER_FILE: $file
	# MATCH: $regex
	# <content>
	# EOM
	# the log host will prepend our IP during the match

    	local $msg = &prep_text ("SPIDER_FILE:" . $file);
	
    	send($csock, $msg, 0, $portaddr) == length($msg) or 
		die "cannot send: $!\n";

	if ($LOG_TYPE) {
		local $msg = &prep_text("SPIDER_TYPE:" . $resp);
		send($csock, $msg, 0, $portaddr) == length($msg) or
			die "cannot send: $!\n";
	}

	local $msg = &prep_text ("MATCH: " . $pat);

        send($csock, $msg, 0, $portaddr) == length($msg) or 
		die "cannot send: $!\n";

	local $msg = &prep_text($frag);
	
	send ($csock, $msg, 0, $portaddr) == length($msg) or 
		die "cannot send: $!\n";

	local $msg = &prep_text("EOM\n");

	send($csock, $msg, 0, $portaddr) == length($msg) or
		die "cannot send: $!\n";

	close($csock);

	return;
}

sub prep_text {
	local $plaintext = shift;
	
	if ($ENCRYPT == 0) {
		return($plaintext);
	}

	# if we're hashing, compute that
	
	if ($USE_HMAC) {
		$hash = MD5 -> hexhash($plaintext);
		$foo = $hash . $plaintext;
		$plaintext = $foo;
	}
	
	# encrypt the block

	$ciphertext = $cipher -> encrypt($plaintext); 

	return($ciphertext);

}

sub read_config {

        # we'd like to make a hash of all the values in the inifile
        tie %ini, 'Config::IniFiles', ( -file => $CONFIG, 
                                        -nocase => 1  );
        

	# Pred S. Bundalo, Wed May 16 09:46:55 CDT 2007
	if (defined($ini{main}{followsymlinks})) {
		$FOLLOWSYMLINKS = $ini{main}{followsymlinks};
	}
	if (defined($ini{main}{unpack})) {
		$UNPACK_ARCHIVES = $ini{main}{unpack};
	}
	if (defined($ini{main}{logfile})) {
        	$LOG_FILE = $ini{main}{logfile};
	}
	if (defined($ini{main}{regexes})) {
        	$REGEXES = $ini{main}{regexes};
	}
	if (defined($ini{main}{use_hmac})) {
        	$USE_HMAC = $ini{main}{use_hmac};
	}
	if (defined($ini{main}{hmac})) {
        	$HMAC = $ini{main}{hmac};
	}
	if (defined($ini{main}{encrypt})) {
        	$ENCRYPT = $ini{main}{encrypt};
	}
	if (defined($ini{main}{key})) {
        	$KEY = $ini{main}{key};
	}
	if (defined($ini{main}{interface})) {
        	$INTERFACE = $ini{main}{interface};
	}
	if (defined($ini{main}{port})) {
        	$PORT = $ini{main}{port};
	}
	if (defined($ini{main}{cipher})) {
        	$CIPHER = $ini{main}{cipher};
	}
	if (defined($ini{main}{loghost})) {
		$LOG_HOST = $ini{main}{loghost};
	}
	if (defined($ini{main}{summary})) {
		$SUMMARY = $ini{main}{summary};
	}
	if (defined($ini{main}{types})) {
		$TYPES = $ini{main}{types};
	}
	if (defined($ini{main}{skip_types})) {
		$SKIP_TYPES = $ini{main}{skip_types};
	}
	if (defined($ini{main}{max_depth})) {
		$MAX_DEPTH = $ini{main}{max_depth};
	}
	if (defined($ini{main}{unprint})) {
		$UNPRINT = $ini{main}{unprint};
	}
	if (defined($ini{main}{log_type})) {
		$LOG_TYPE = $ini{main}{log_type};
	}
	if (defined($ini{main}{log_http})) {
		$LOG_HTTP = $ini{main}{log_http};
	}
	if (defined($ini{main}{log_url})) {
		$LOG_URL = $ini{main}{log_url};
	}
	
	if ($LOG_HTTP) {
		unless(defined($LOG_URL)) {
			die "need a log URL!\n";
		}
	}

	$UNPRINT =~ s/\"//g;

	unless ($quiet) {
		print "log file:$LOG_FILE\n";
		print "regex file:$REGEXES\n";
		print "use HMAC:$USE_HMAC\n";
		print "HMAC:$HMAC\n";
		print "Encrypt:$ENCRYPT\n";
		print "Interface:$INTERFACE\n";
		print "Port:$PORT\n";
		print "Cipher:$CIPHER\n";
		print "log host:$LOG_HOST\n";
		print "summary: $SUMMARY\n";
		print "maximum file types to report: $TYPES\n";
		print "list of file types to skip: $SKIP_TYPES\n";
	}

	if (defined($SKIP_TYPES)) {
		open IFILE, "< $SKIP_TYPES" or die "cannot open $SKIP_TYPES:$!\n";
		while (<IFILE>) {
			chomp;
			push(@skip_types, qr/$_/);
		}
		close IFILE;
	}

	if ($USE_HMAC) {
		# MAX_LEN needs to be adjusted to accomodate the
		# HMAC, and be padded out to a multiple of the cipher
		# block size
		$OLD_MAX = $MAX_LEN;
		$MAX_LEN += (32 * 2) + 64;
		# if that leaves us over what'll fit in a UDP packet,
		# bitch
		if ($MAX_LEN > 1400) {
			print "$MAX_LEN packet length too long.\n";
			exit(1);
		}
	}

	if (!defined($UNPRINT)) {
		$UNPRINT = ".";
	}

        return;


}

sub send_summary {
	# a summary consists of:
	# total files:
	# breakdown by type

	# we'll construct the summary and send it off in $MAX_LEN packet
	# sizes

	$summary = "SUMMARY\nProcessed: $filecount total files\n";
	$summary .= "Files skipped: $skipped\n";
	$summary .= "Breakdown follows:\n";

	if ($types) {
		$count = 0;
	}

	foreach $ftype ( sort { $files_by_type{$b} <=> $files_by_type{$a} } keys %files_by_type) {
		if ($types) {
			if ($count >= $types) { break; }
		}
		$summary .= "$ftype: $files_by_type{$ftype}\n";
		$count++;
	}	



	$start = 0;
	$offset = $OLD_MAX_LEN;
	
	$ip_addr = inet_aton($LOG_HOST);
    	$portaddr = sockaddr_in($PORT, $ip_addr);
    	$start = 0;
	$sent = 0;

    	$csock = IO::Socket::INET -> new(Proto => 'udp')
                or die "socket: $@\n";

	while (($start + $offset) <= length($summary)){
		$tosend = prep_text(substr($summary, $start, $offset));	
   		$sent += send($csock, $tosend, 0, $portaddr) == length($tosend) or 
			die "cannot send: $!\n";
		$start += $offset;
	}
	
	if (length(substr($summary, $start, $offset))) {
		$tosend = prep_text(substr($summary, $start, $offset));
		$sent += send($csock, $tosend, 0, $portaddr) == length($tosend) or
			die "cannot send: $!\n";
	}
	

	return;

}

sub create_archive_command {

	# first off, create a temporary directory for the archive contents
	#
	$t_file = $file;
	$t_file = s/ /\\ /g;
	$ARK_DIR = tempdir( DIR => "/tmp", CLEANUP => 1 );
	if ($resp =~ m/Zip archive/) {
		$CMD = $UNZIP . " " . $t_file . " -d " . $ARK_DIR;
		return;
	}

	if ($resp =~ m/RAR archive/) {
		$CMD = $UNRAR . " e " . $t_file . " " . $ARK_DIR;
		return;
	}

	if ($resp =~ m/Zoo archive/) {
		$CMD = $ZOO . " -x -j " . $ARK_DIR . " " . $t_file;
		return;
	}

	if ($resp =~ m/ARJ archive/) {
		$CMD = $ARJ . " e -w " . $ARK_DIR . " " . $t_file;
		return;
	}

	# add more archive support here ...
	$CMD = "/bin/true";

	return;
}

sub set_tool_paths {
	local $True = "/bin/true";

	if (! -x $STRINGS) {
		$p = `which strings`;
		chomp($p);
		if ($? >> 8) { $STRINGS = $True; } else { $STRINGS = $p; }
	}

	if (! -x $FILE) {
		$p = `which file`;
		chomp($p);
		if ($? >> 8) { $FILE = $True; } else { $FILE = $p; }
	}

	if (! -x $WV) {
		$p = `which wvText`;
		if ($? >> 8) { $WV = $True; } else { $WV = $p; }
	}

	if (! -x $UNZIP) {
		$p = `which unzip`;
		chomp($p);
		if ($? >> 8) { $UNZIP = $True; } else { $UNZIP = $p; }
	}

	if (! -x $UNRAR) {
		$p = `which unrar`;
		chomp($p);
		if ($? >> 8) { $UNRAR = $True; } else { $UNRAR = $p; }
	}

	if (! -x $LHA) {
		$p = `which lha`;
		chomp($p);
		if ($? >> 8) { $LHA = $True; } else { $LHA = $p; }
	}

	if (! -x $ZOO) {
		$p = `which unzoo`;
		chomp($p);
		if ($? >> 8) { $ZOO = $True; } else { $ZOO = $p; }
	}

	if (! -x $ARJ) {
		$p = `which arj`;
		chomp($p);
		if ($? >> 8) { $ARJ = $True; } else { $ARJ = $p; }
	}

	if (! -x $READPST) {
		$p = `which readpst`;
		chomp($p);
		if ($? >> 8) { $READPST = $True; } else { $READPST = $p; }
	}

	if ($DEBUG) {
		print "Using tools:\n";
		print "$STRINGS\n";
		print "$FILE\n";
		print "$WV\n";
		print "$UNZIP\n";
		print "$UNRAR\n";
		print "$ZOO\n";
		print "$ARJ\n";
		print "$LHA\n";
		print "$READPST\n";
		print "\n";
	}
	return;
}

sub sig_handler {
	print "Stopping spider client\n";
	exit(1);
}

sub unzip_file ($$) {
	my($file_to_unzip,$dest_dir) = @_;
	
	$zip = Archive::Zip->new();
	unless ($quiet) {
		print "Using Archive::Zip to inflate $file_to_unzip\n";
		print "Type: $resp\n";
	}

	$ret = $zip -> read($file_to_unzip);

	unless ($ret == AZ_OK) {
		return;
	}

	$count = 1;

	$encrypted_zips = 0;

	for $mem ($zip -> members()) {
		if ($mem -> isEncrypted) {
			$encrypted_zips++;	
		}
		if ($mem -> isDirectory) { next; }
		$method = $mem -> compressionMethod;
		my($oldc) = $mem->desiredCompressionMethod(COMPRESSION_STORED);
		$output = $dest_dir . "/" . $count;
		open ZOFILE, "> $output";
		binmode ZOFILE;
		$sts = $mem -> rewindData();
		while ($sts == AZ_OK) {
			($buf_ref, $sts) = $mem -> readChunk();
			unless ($sts == AZ_OK || $sts == AZ_STREAM_END) {
				close ZOFILE;
				return;
			}
			print ZOFILE $$buf_ref;
		}
		close OFILE;
                $mem->desiredCompressionMethod($oldc);
		$mem -> endRead();
		$count++;
	} # end for

}
