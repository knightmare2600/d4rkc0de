#!/usr/bin/perl


use Getopt::Std;
use Socket;
use IO::Socket;
use POSIX;
use Config::IniFiles;
use MD5; # used if crypto is enabled
use Crypt::CBC; # used if crypto is enabled
use Fcntl;

$PORT = 3000;
$LOG_FILE = "/tmp/logfile";
$REGEXES= "REGEXES";
$MAX_LEN = 1024;
$CONFIG = "spider.conf";
$TRANSLATE_MAP = "TRANSLATE_MAP";
$INTERFACE = "127.0.0.1";
$ENCRYPT = 0;
$CIPHER = "Blowfish";
$NEW_CONFIG = "/tmp/spider.conf";
$PID_LOC = "/var/tmp/spider.pid";
$DEBUG_LOC = "/var/tmp/spider.debug";
$SPIDER_CONF_PATH = "/var/tmp/spider_conf_path";
$HTML_RESULTS = 0;

$OFF = 15;

%results_hash = ();
%translate_paths = ();

&getopts('l:R:c:');

if ($opt_c) {
	$CONFIG = $opt_c;
	# this allows the remaining options to override anything in 
	# the config file
}

if ($opt_l) {
    $LOG_FILE = $opt_l;
}

if ($opt_R) {
    $REGEXES = $opt_R;
}

&read_config;
# let's get Crypt::CBC warmed up

if ($ENCRYPT) {
	$cipher = Crypt::CBC -> new( { 'key' => $KEY, 
					'cipher' => $CIPHER
					} );
}
# what we'll do is open a series of listeners to accept 
# matching submissions from spider runs

print "Starting regex matching processes\n";

#open LOG, "> $LOG_FILE" or die "cannot open $LOG_FILE:$!\n";
#select((select(LOG), $| = 1)[0]);
#print LOG "GIF89a\n\n";

$pid = fork();
exit if $pid;

die "Can't fork:$!\n" unless defined($pid);
$sess = POSIX::setsid() or die "Can't start new session:$!\n";
close STDIN;
close STDOUT;
close STDERR;


$SIG{TERM} = $SIG{HUP} = $SIG{INT} = \&sig_handler;
$SIG{USR1} = \&sig_usr1;

# write out our pid
open PID, "> $PID_LOC" or die "can't open $PID_LOC:$!\n";
print PID "$sess\n";
close PID;

# write our config path
open C, "> $SPIDER_CONF_PATH" or die "can't open $SPIDER_CONF_PATH:$!\n";
if ($RANDOM_KEY) {
	print C "$NEW_CONFIG\n";
} else {
	print C "$CONFIG\n";
}
close C;

# load up the regexes and get ready to start matching
$count = 0;
$matches = 0;

open IFILE, "< $REGEXES" or die "cannot open $REGEXES:$!\n";


while (<IFILE>) {
    next if (/^\n/ || /^\#/);
    chomp;
    $regex = $_;
    push(@regexes, qr/$regex/);
    $count++;
}

close IFILE;


# grab the translate map


open IFILE, "< $TRANSLATE_MAP" or die "cannot open $TRANSLATE_MAP:$!\n";

while (<IFILE>) {
	next if (/^\#/);
	next if (/^\n/);
	chomp;
	($here,$there) = split/\t/;
	$translate_paths{$here} = $there;
}

close IFILE;


# open the matching socket

if ($INTERFACE eq "ANY") { 
	$sock = IO::Socket::INET -> new(LocalPort => $PORT,
					Proto => 'udp');
} else {
	$sock = IO::Socket::INET -> new(LocalPort => $PORT,
				LocalAddr => $INTERFACE,
				Proto => 'udp');
}

$received = 0;
$PEER_ADDR = "127.0.0.1"; # will override later if necessary

while ($sock -> recv($_, $MAX_LEN)) {
    # if our interface is something other than localhost, we want to
    # grab the peer address from the other end of the socket
    unless ($INTERFACE eq "127.0.0.1") {
	($remoteport, $remoteaddr) = unpack_sockaddr_in($sock -> peername);
	$PEER_ADDR = inet_ntoa($remoteaddr);
    }

    if ($ENCRYPT) {
	# will return $_ as either a valid packet of 1024 bytes or
	# SPIDER_DECRYPT_ERROR otherwise
	$_ = &decrypt_packet($_);
	if (/SPIDER_DECRYPT_ERROR/) { return; }
    }


    $CURR_LOG = $LOG_FILE;
    $CURR_LOG =~ s/IP/$PEER_ADDR/;
    if ($HTML_RESULTS) { $CURR_LOG .= ".html"; }
    if (-e $CURR_LOG) {
	if ($HTML_RESULTS) {
		sysopen(LOG, $CURR_LOG, O_RDWR, 0644);
	} else {
		open LOG, ">> $CURR_LOG";
	}
    	select((select(LOG), $| = 1)[0]);
    } else {
	if ($HTML_RESULTS) {
		sysopen(LOG, $CURR_LOG, O_RDWR | O_CREAT, 0644);
	} else {
		open LOG, "> $CURR_LOG";
	}
	select((select(LOG), $| = 1)[0]);
	if ($HTML_RESULTS) {
		print LOG "<HTML><TITLE>Spider results for $PEER_ADDR</TITLE>\n";
		print LOG "<BODY>\n";
		print LOG "<A NAME=\"top\"></A><BR>\n";
		print LOG "xxxxxxxxxxxxxxx";
	} 
    }
    if ($HTML_RESULTS) {
	# we need to populate the array "owned" by this IP address
	if (/EOM/) {
		&write_log;
		undef(@ { $results_hash{$PEER_ADDR} });
	} else {
		push @{ $results_hash{$PEER_ADDR} }, $_;
	}
    }
    &write_log;
    close LOG;
    $received++;
}

exit(0);

sub write_log {
	local %results;
	local @temp_store;
	local $results_linecount = 0;
	if ($HTML_RESULTS) {
		$size = (stat($CURR_LOG))[7];
		$offset = ($size - $OFF);
		sysseek(LOG, $offset, 0);
		# we'll sort through the array until we find the necessary 
		# elements
		@baz = @{ $results_hash{$PEER_ADDR} };
		foreach $_ (@baz) {
			if (/SPIDER_FILE/) {
				s/SPIDER_FILE://;
				if ($HTML_REWRITE) {
					foreach $here (keys %translate_paths) {
						s/$here/$translate_paths{$here}/;
					}
					s/\/{1,3}/\//g;
					$URL = "file:///" . $_;
					s/\//\\/g;
				}
				$results{'SPIDER_FILE'} = $_;
			} elsif (/SPIDER_TYPE/) {
				s/SPIDER_TYPE://;
				$results{'SPIDER_TYPE'} = $_;
			} elsif (/MATCH:/) {
				s/MATCH//;
				$results{'MATCH'} = $_;
			} else {
				foreach $pat (@regexes) {
					if (/$pat/) {
						$results{'MATCH'} = $pat;
					}
				}
				if ($HTML_RESULTS) {
					s/\</\&lt;/g;
					s/\>/\&gt;/g;
				}
				push(@temp_store, $_);
				$results_linecount += length($_);
			}
		}
		if (!defined($results{'SPIDER_FILE'})) {
			$results{'SPIDER_FILE'} = "<pre> </pre>";
		}
		if (!defined($results{'SPIDER_TYPE'})) {
			$results{'SPIDER_TYPE'} = "<pre> </pre>";
		}
		if (defined($results{'MATCH'}) && ($results_linecount)) {
			$URL =~ s/\s/\%20/g;
			print LOG "<TABLE border=\"1\">\n";
			print LOG "<TR><TD>IP:</TD><TD><pre>$PEER_ADDR</pre></TD></TR>\n";
			print LOG "<TR><TD>File:</TD><TD><A HREF=\"$URL\">$results{'SPIDER_FILE'}</A></TD></TR>\n";
			print LOG "<TR><TD>Type:</TD><TD>$results{'SPIDER_TYPE'}</TD></TR>\n";
			print LOG "<TR><TD>Regex:</TD><TD>$results{'MATCH'}</TD></TR>\n";
			print LOG "<TR><TD><Snip:</TD><TD><pre>@temp_store</pre></TD></TR>\n";
			print LOG "</TABLE>\n";
			print LOG "<A HREF=\"#top\">Back to top</A>\n<BR>\n";
			print LOG "<P>\n";
		}
		print LOG "</BODY></HTML>\n";
		undef @temp_store;
		undef %results;
	} else {
		# vanilla results
		print LOG "\n[$PEER_ADDR] $_";
		foreach $pat (@regexes) {
			if (/$pat/) {
				print LOG "\n[$PEER_ADDR] MATCH: $pat\n";
				print LOG "\n[$PEER_ADDR] $_\n";
			}
		}
	}
	return;
}

sub sig_handler {
    # for HUPs, we'll do two things: truncate the log file
    # and reopen it, and re-read the regexes
    print "caught signal.  exiting.\n";
    close LOG;
    close $sock;
    exit(0);
}

sub sig_usr1 {
    # don't quite know what to do here.
    return;
}

sub read_config {

	# we'd like to make a hash of all the values in the inifile
	tie %ini, 'Config::IniFiles', ( -file => $CONFIG, 
					-nocase => 1  );
	

	if (defined($ini{main}{logfile})) {
		$LOG_FILE = $ini{main}{logfile};
	}

	if (defined($ini{main}{regexes})) {
		$REGEXES = $ini{main}{regexes};
	}
	if (defined($ini{main}{use_hmac})) {
		$USE_HMAC = $ini{main}{use_hmac};
	}
	if (defined($ini{main}{hmac})) {
		$HMAC = $ini{main}{hmac};
	}
	if (defined($ini{main}{encrypt})) {
		$ENCRYPT = $ini{main}{encrypt};
	}
	if (defined($ini{main}{key})) {
		$KEY = $ini{main}{key};
	}
	if (defined($ini{main}{interface})) {
		$INTERFACE = $ini{main}{interface};
	}
	if (defined($ini{main}{port})) {
		$PORT = $ini{main}{port};
	}
	if (defined($ini{main}{cipher})) {
		$CIPHER = $ini{main}{cipher};
	}
	if (defined($ini{main}{random_key})) {
		$RANDOM_KEY = $ini{main}{random_key};
	}
	if (defined($ini{main}{key_length})) {
		$KEY_LENGTH = $ini{main}{key_length};
	}
	if (defined($ini{main}{log_type})) {
		$LOG_TYPE = $ini{main}{log_type};
	}
	if (defined($ini{main}{html_results})) {
		$HTML_RESULTS = $ini{main}{html_results};
	}
	if (defined($ini{main}{html_rewrite_paths})) {
		$HTML_REWRITE = $ini{main}{html_rewrite_paths};
	}
	if (defined($ini{main}{translate_map})) {
		$TRANSLATE_MAP = $ini{main}{translate_map};
	}

	unless ($KEY_LENGTH >= 10) {
		$KEY_LENGTH = 20;
	}

	if ($RANDOM_KEY) {
		# grab KEY_LENGTH worth of printable characters from
		# /dev/random  
		open IFILE, "< /dev/random" or die "unable to open /dev/random for reading: $!\n";
		binmode IFILE;
		$ret = sysread(IFILE, $foo, $KEY_LENGTH);
		unless ($ret == $KEY_LENGTH) {
			die "short read from /dev/random.  asked $KEY_LENGTH;got $ret\n";
		}
		$KEY = unpack("H*", $foo);
		close IFILE;
		# write this to the conf file
		$ini{main}{key} = $KEY;
		tied(%ini) -> WriteConfig ( $NEW_CONFIG ) or die "cannot rewrite spider.conf!:$NEW_CONFIG:$!\n";
	}

	if ($USE_HMAC) { 
		# MAX_LEN will have to now include the size of the HMAC
		# plus be an integer multiple of the cipher block size
		$MAX_LEN += (32 *2);
		if ($MAX_LEN % 64) {
			$MAX_LEN += 64;
		}
		# if that's over what can comfortably fit in a UDP packet,
		# bitch.  I don't feel like doing packet reassembly
		if ($MAX_LEN > 1400) {
			print "$MAX_LEN packet length too long.\n";
			exit(1);
		}
	}

	print "log file: $LOG_FILE\n";
	print "regexes: $REGEXES\n";
	print "use HMAC: $USE_HMAC\n";
	print "encrypt: $ENCRYPT\n";
	print "interface: $INTERFACE\n";
	print "port: $PORT\n";
	print "cipher: $CIPHER\n";
	
	untie(%ini);

	return;

}

sub decrypt_packet {
	local $ciphertext = shift;
	return unless length($ciphertext) > 0;
	# here's how it's going to look:
	#
	# [32 bytes MD5][packet data]
	#
	# we'll do the decrypt and grab the first 20 characters of the 
	# result.  That ought to match the md5 of  the remainder of the
	# data.  If not, set $_ to the error message

	# if we're not using HMAC, we just return whatever decrypts and 
	# hope for the best

		
	$plaintext = $cipher -> decrypt($ciphertext);


	if ($USE_HMAC) {
		$hash = substr($plaintext,0,32);
		$text = substr($plaintext, 32);
		$len = length($text);

	
		$testhash = MD5 -> hexhash($text);

		if ($hash ne $testhash) {
			$resp = "SPIDER_DECRYPT_ERROR got: " . $hash . " expected: " . $testhash . " length: " . $len;
			return($resp);
		}
	} else {
		return($plaintext);
	}

	return($text);

}
