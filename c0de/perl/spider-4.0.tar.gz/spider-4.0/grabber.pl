#!/usr/bin/perl

use Getopt::Std;

$LOG = "/tmp/logfile";
$OUTDIR = "/tmp/spider";
$MKISOFS = "/usr/bin/mkisofs";
$verbose = 1;

&getopts('Ca:m:l:o:');

if ($opt_C) {
	print "Output filename: ";
	$outfile = <>;
	$outfile =~ s/\n//;
	print "\n";
	print "Volume label: ";
	$label = <>;
	$label =~ s/\n//;
	print "Will use: \"" . substr($label, 0, 10) . "\"\n";
}

if ($opt_a) {
	$ADDR = $opt_a;
	$ADDR =~ s/\./\\./g;
}

if ($opt_m) {
	(@MOUNT) = split/\//, $opt_m;
}

if ($opt_l) {
	$LOG = $opt_l;
}

if ($opt_o) {
	$OUTDIR = $opt_o;
}

if ($opt_v) {
	$verbose = 1;
}

# we'll rip through the spider log collecting files
# into the new directory;
# if we run into a name collision, we'll prepend numbers until we
# get a unique file name
#
# we'll put the numbers at the start of the file name so as not to
# screw up the all-important Windows filename extensions.  Yak.

open LFILE, "< $LOG" or die "cannot open log file: $LOG\n";

$filecount = 0;

while (<LFILE>) {
	s/\n//;
	if (/SPIDER_FILE/) {
		if (defined($ADDR)) {
			next unless (/$ADDR/);
		}
		($foo, $filename) = split/:/;
		if ($verbose) {
			print "Grabbing path: $filename\n";
		}
		(@crap) = split/\//, $filename;
		if (@MOUNT) {
			$i = 0;
			while ($i <= $#MOUNT) {
				$crap[$i] = $MOUNT[$i];
				$i++;
			}
			$filename = join('/', @crap);
			if ($verbose) {
				print "Converted path: $filename\n";
			}
		}
		$base = $crap[$#crap];
		$outfile = $OUTDIR . "/" . $base;
		if (-e $outfile) {
			$count = 1;
			while (-e $outfile) {
				$outfile = $OUTDIR . "/" . $count . "_" . $base;
				$count++;
			}
			if ($verbose) {
				print "$base already exists, creating new file $outfile\n";
			}
		}
		open OFILE, "> $outfile" or die "cannot open $outfile:$!\n";
		open IFILE, "< $filename" or die "cannot read $filename:$!\n";
		binmode OFILE;
		binmode IFILE;
		while (<IFILE>) {
			print OFILE;
		}
		close IFILE;
		close OFILE;
		$filecount++;
	}
}

close LFILE;

print "Processed $filecount files to $LOGDIR\n";

if (defined($outfile)) {
	print "Creating ISO:\n";
	$CMD = $MKISOFS . " -R -U -V \"" . $label . "\" -no-bak -pad -o " . $outfile . " " . $OUTDIR;
	system ($CMD);
}

exit 0;
