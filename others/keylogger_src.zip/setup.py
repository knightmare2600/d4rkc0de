# setup.py
from distutils.core import setup
import py2exe

setup(console=[{"script":"C:\\logger\\server.py","icon_resources":[(1,"C:\\logger\\shinobi.ico")]}])
