PACKAGE = "fusil"
VERSION = "0.9"
WEBSITE = "http://fusil.hachoir.org/"
LICENSE = "GNU GPL v2"
