PACKAGE = "ptrace"
VERSION = "0.3.1"
WEBSITE = "http://fusil.hachoir.org/trac/wiki/Ptrace"
LICENSE = "GNU GPL v2"
