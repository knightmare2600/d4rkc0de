from ptrace.syscall.names import SYSCALL_NAMES
from ptrace.syscall.prototypes import SYSCALL_PROTOTYPES, FILENAME_ARGUMENTS
from ptrace.syscall.syscall_argument import SyscallArgument
from ptrace.syscall.ptrace_syscall import PtraceSyscall

