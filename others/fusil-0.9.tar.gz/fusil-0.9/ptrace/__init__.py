from ptrace.signames import SIGNAMES, signalName
from ptrace.error import PtraceError

