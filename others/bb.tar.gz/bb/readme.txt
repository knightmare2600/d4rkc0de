Brute_Blocker

by Phate

web: http://phate.hercodesigns.com
email: my_phate@yahoo.es 

Es un script en Python muy simple. El unico objetivo del programa, es
bloquear un intento de "login" mediante bruteforce.

He is script in very simple Python.  The objective of the program, is 
to block an attempt of "login" by means of bruteforce.

INSTALL

1�

./install.sh

2� config your swatch (.swatchrc)
   check swatchrc_sample for a example