#!/bin/sh

#PERMISOS
#-rw-r--r--  1 root root    1 2005-02-12 21:59 /etc/hosts.deny
#-rw-r--r--  1 root root   10 2005-02-11 15:01 /etc/blacklist
#-rwxr--r--  1 root root 1478 2005-02-11 15:04 .punix.py


touch /etc/blacklist
cp punix.py /root/.punix.py