See the project website: 
http://pykeylogger.sourceforge.net/ 
for instructions on using pykeylogger. it is updated frequently.
