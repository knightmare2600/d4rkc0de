
name = "pykeylogger"
version = "0.9.1"
description = "Simple Python Keylogger for Windows"
url = "http://pykeylogger.sourceforge.net"
license = "GPL"
author = "Nanotube"
author_email = "nanotube@users.sf.net"
platform = "Windows NT/2000/XP"